
const oceankorewallet_settings = window.wc.wcSettings.getSetting( 'oceankorewallet_data', {} );


const oceankorewallet_label = window.wp.htmlEntities.decodeEntities( oceankorewallet_settings.title ) || window.wp.i18n.__( 'Oceanpayment Kor Ewallet Payment Gateway', 'oceanpayment-korewallet-gateway' );




const oceankorewallet_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceankorewallet_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceankorewallet-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceankorewallet_Block_Gateway = {
    name: 'oceankorewallet',

    label: React.createElement(I, {
        id: "oceankorewallet",
        title: oceankorewallet_settings.title,
        icons: oceankorewallet_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceankorewallet_Content, null ),
    edit: Object( window.wp.element.createElement )( oceankorewallet_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceankorewallet_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-korewallet-gateway' ),
  /*  supports: {
        features: oceankorewallet_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceankorewallet_Block_Gateway );