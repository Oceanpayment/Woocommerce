<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceankorewallet_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceankorewallet';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceankorewallet_settings', [] );
        $this->gateway = new WC_Gateway_Oceankorewallet();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceankorewallet-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceankorewallet-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceankorewallet-blocks-integration');
            
        }


        return [ 'oceankorewallet-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'korewallet_icon',
            'alt' => 'Kor Ewallet',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_korewallet.png' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>