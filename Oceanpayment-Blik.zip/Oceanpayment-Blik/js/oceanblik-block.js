
const oceanblik_settings = window.wc.wcSettings.getSetting( 'oceanblik_data', {} );


const oceanblik_label = window.wp.htmlEntities.decodeEntities( oceanblik_settings.title ) || window.wp.i18n.__( 'Oceanpayment Blik Payment Gateway', 'oceanpayment-blik-gateway' );




const oceanblik_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanblik_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanblik-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanblik_Block_Gateway = {
    name: 'oceanblik',

    label: React.createElement(I, {
        id: "oceanblik",
        title: oceanblik_settings.title,
        icons: oceanblik_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanblik_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanblik_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanblik_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-blik-gateway' ),
  /*  supports: {
        features: oceanblik_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanblik_Block_Gateway );