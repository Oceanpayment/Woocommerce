<?php
/*
	Plugin Name: Oceanpayment Blik Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment Blik Gateway.
	Version: 6.0
	Author: Oceanpayment
	Requires at least: 4.0
	Tested up to: 6.1
    Text Domain: oceanpayment-blik-gateway
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceanblik', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceanblik_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.2
 */
function woocommerce_oceanblik_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceanblik.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceanblik_add_gateway' );

} // End woocommerce_oceanblik_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.2
 */
function woocommerce_oceanblik_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceanblik';
	return $methods;
} // End woocommerce_oceanblik_add_gateway()