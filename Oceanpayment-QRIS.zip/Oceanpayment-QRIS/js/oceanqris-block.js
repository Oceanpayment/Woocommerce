
const oceanqris_settings = window.wc.wcSettings.getSetting( 'oceanqris_data', {} );


const oceanqris_label = window.wp.htmlEntities.decodeEntities( oceanqris_settings.title ) || window.wp.i18n.__( 'Oceanpayment QRIS Payment Gateway', 'oceanpayment-qris-gateway' );




const oceanqris_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanqris_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanqris-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanqris_Block_Gateway = {
    name: 'oceanqris',

    label: React.createElement(I, {
        id: "oceanqris",
        title: oceanqris_settings.title,
        icons: oceanqris_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanqris_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanqris_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanqris_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-qris-gateway' ),
  /*  supports: {
        features: oceanqris_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanqris_Block_Gateway );