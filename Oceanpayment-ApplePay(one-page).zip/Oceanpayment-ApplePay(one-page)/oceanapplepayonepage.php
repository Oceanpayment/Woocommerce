<?php
/*
	Plugin Name: Oceanpayment Applepay One-Page
	Plugin URI: http://www.oceanpayment.com/
	Description: Oceanpayment Applepay One-Page.
	Version: 1.0
	Author: Oceanpayment
	Requires at least: 4.0
	Tested up to: 6.1
    Text Domain: oceanpayment-applepayonepage-gateway
*/
defined('ABSPATH') || exit;

/**
 * Plugin updates
 */




add_filter('woocommerce_payment_gateways', 'woocommerce_oceanapplepayonepage_add_gateway' );
load_plugin_textdomain( 'oceanpayment-applepayonepage-gateway', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );
add_action( 'plugins_loaded', 'woocommerce_oceanapplepayonepage_init', 0 );

add_filter('woocommerce_order_button_html', 'hide_order_button_for_oceanapplepayonepage');

function hide_order_button_for_oceanapplepayonepage($button_html) {
    // 获取当前选中的支付方式
    $chosen_payment_method = WC()->session->get('chosen_payment_method');
    
    // 如果当前支付方式在列表中，返回空字符串（隐藏按钮）
    if ($chosen_payment_method == 'oceanapplepayonepage') {
        // 添加自定义类和样式
        $button_html = str_replace(
            '">',
            '" style="display:none;">',
            $button_html
        );
        return $button_html;
    }
    
    return $button_html;
}


add_action('wp_footer', 'disable_apple_place_order_button_conditionally');
function disable_apple_place_order_button_conditionally() {
    if (!is_checkout()) return; // 仅作用于结账页面
    ?>
    <script type="text/javascript">
        window.addEventListener('load', function() {
            // 假设有一个选中的单选按钮
            if(document.querySelector('input[name="radio-control-wc-payment-method-options"]')){
                var selectedValue = document.querySelector('input[name="radio-control-wc-payment-method-options"]').value;
                if(selectedValue == 'oceanapplepayonepage' || selectedValue == 'oceangooglepayonepage'){
                        document.querySelector('.contained').style.display = 'none';
                }
            }
        });
        jQuery(document).ready(function($) {
            
            $(document.body).on('change', 'input[name="radio-control-wc-payment-method-options"]', function() {
                var paymentMethod = $(this).val();
                console.log(paymentMethod);
                if(paymentMethod == 'oceanapplepayonepage' || paymentMethod == 'oceangooglepayonepage'){
                    document.querySelector('.contained').style.display = 'none';
                }else{
                    document.querySelector('.contained').style.display = '';
                }
            })
        })
    </script>
    <div id="apple_order-loading-overlay" style="display: none;">
    <div class="apple_loading-spinner"></div>
    <!-- 可以添加文字 -->
    <p>loading...</p>
    </div>
    <?php
}

/**
 * Initialize the gateway.
 *
 * @since 1.4
 */
function woocommerce_oceanapplepayonepage_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceanapplepayonepage.php' ) );

} // End woocommerce_oceanapplepayonepage_init()


/**
 * Add the gateway to WooCommerce
 *
 * @since 1.4
 */
function woocommerce_oceanapplepayonepage_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceanapplepayonepage';
	return $methods;
} // End woocommerce_oceanapplepayonepage_add_gateway()

/**
 * Custom function to declare compatibility with cart_checkout_blocks feature
 */
function wc_oceanapplepayonepage_declare_cart_checkout_blocks_compatibility() {
    // Check if the required class exists
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        // Declare compatibility for 'cart_checkout_blocks'
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
}
// Hook the custom function to the 'before_woocommerce_init' action
add_action('before_woocommerce_init', 'wc_oceanapplepayonepage_declare_cart_checkout_blocks_compatibility');

add_action('wp_ajax_wc_applepayonepage_create_order', 'wc_applepayonepage_create_order');
add_action('wp_ajax_nopriv_wc_applepayonepage_create_order', 'wc_applepayonepage_create_order');
add_action('wp_ajax_wc_apple_pay_confirm_payment', 'wc_apple_pay_confirm_payment');
add_action('wp_ajax_nopriv_wc_apple_pay_confirm_payment', 'wc_apple_pay_confirm_payment');
// 创建订单（为Apple Pay提供配置）
    function wc_applepayonepage_create_order() {
        try {
            // 安全验证
            if (!wp_verify_nonce($_POST['security'],'oceanapplepayonepage',)) {
                throw new Exception(__('安全验证失败，请刷新页面重试', 'woocommerce'));
            }
            
            // 验证并清理数据
            $billing = [
                'first_name' => sanitize_text_field($_POST['data']['billing_first_name']),
                'last_name'  => sanitize_text_field($_POST['data']['billing_last_name']),
                'email'      => sanitize_email($_POST['data']['billing_email']),
                'phone'      => sanitize_text_field($_POST['data']['billing_phone']),
                'country'    => sanitize_text_field($_POST['data']['billing_country']),
                'state'    => sanitize_text_field($_POST['data']['billing_state']),
                'address_1'  => sanitize_text_field($_POST['data']['billing_address_1']),
                'city'       => sanitize_text_field($_POST['data']['billing_city']),
                'postcode'   => sanitize_text_field($_POST['data']['billing_postcode']),
                // 其他字段...
            ];
            
            // 验证必要数据
            if (!is_email($billing['email'])) {
                throw new Exception(__('无效的电子邮箱地址', 'woocommerce'));
            }
            
            // 创建订单
            $order = wc_create_order([
                'customer_id' => is_user_logged_in() ? get_current_user_id() : 0,
                'status'      => 'pending'
            ]);
            
            if (!$order || is_wp_error($order)) {
                throw new Exception(__('创建订单失败', 'woocommerce'));
            }
            
            // 添加地址
            $order->set_address($billing, 'billing');
            $order->set_address($billing, 'shipping');
            
            // 添加购物车商品
            $cart = WC()->cart;
            foreach ($cart->get_cart() as $cart_item) {
                $item_id = $order->add_product(
                    $cart_item['data'],
                    $cart_item['quantity'],
                    ['variation' => $cart_item['variation']]
                );
            }
            
                $productName = array();
                $productSku = array();
                $productNum = array();
                $productPrice = array();
            foreach ($order->get_items() as $item_key => $item ){
                $item_data = $item->get_data();
                $product = $item->get_product();
                $item_data['quantity'] != '' ? $productNum[] = substr($item_data['quantity'], 0,50) : $productNum[] = 'N/A';
                $product->get_sku() != '' ? $productSku[] = substr($product->get_sku(), 0,500) : $productSku[] = 'N/A';
                $product->get_name() != '' ? $productName[] = substr($product->get_name(), 0,500) : $productName[] = 'N/A';
                $product->get_price() != '' ? $productPrice[] = substr($product->get_price(), 0,500) : $productPrice[] = 'N/A';
            }
            
            // 设置支付方式
            $order->set_payment_method($_POST['data']['payment_method']);
            $order->set_payment_method_title('Oceanpayment Applepay Gateway');
            
            // 计算总额
            $order->calculate_totals();
            $order->save();
            $account = get_option('woocommerce_oceanapplepayonepage_settings')['account'];
            $terminal = get_option('woocommerce_oceanapplepayonepage_settings')['terminal'];
            $securecode = get_option('woocommerce_oceanapplepayonepage_settings')['securecode'];
            $backUrl = WC()->api_request_url( 'return_' . $_POST['data']['payment_method'] );
            $noticeUrl = WC()->api_request_url( 'notice_' . $_POST['data']['payment_method'] );
            
            // 构建Apple Pay支付参数
            $payment_config = [
                'account' => $account, 
                'terminal' => $terminal,
                'signValue' => hash("sha256",$account.$terminal.$order->get_id().$order->get_currency().$order->get_total().$billing['first_name'].$billing['last_name'].$billing['email'].$securecode),
                'backUrl' => $backUrl,
                'noticeUrl' => $noticeUrl,
                'methods' => 'ApplePay',
                'order_notes' => '',
                'noticeUrl' => $noticeUrl,
                'noticeUrl' => $noticeUrl,
                'order_amount' => $order->get_total(),
                'order_currency' => $order->get_currency(),
                'order_number' => $order->get_id(),
                'billing_firstName' => $billing['first_name'],
                'billing_lastName'  => $billing['last_name'],
                'billing_email'      => $billing['email'],
                'billing_phone'      => $billing['phone'],
                'billing_country'    => $billing['country'],
                'billing_state'    => $billing['state'],
                'billing_address'  => $billing['address_1'],
                'billing_city'       => $billing['city'],
                'billing_zip'   => $billing['postcode'],
                'billing_ip'   => $_SERVER['REMOTE_ADDR'],
                'productSku'       => implode(';', $productSku),
                'productName'   => implode(';', $productName),
                'productNum'   => implode(';', $productNum),
                'productPrice'   => implode(';', $productPrice),
            ];
            if(get_option('woocommerce_oceanapplepayonepage_settings')['log'] == true){
                        //记录发送到oceanpayment的post log
                $oceanpayment_log_url = dirname( __FILE__ ).'/oceanpayment_log/';
        
                $filedate = date('Y-m-d');
        
                $postdate = date('Y-m-d H:i:s');
        
                $newfile  = fopen( $oceanpayment_log_url . $filedate . ".log", "a+" );
                $text = '';
                foreach($payment_config as $key=>$item){
                        $text .= $key.'='.$item."\r\n";
                    };
        
                $post_log = $postdate."[POST to Oceanpayment]\r\n" .$text;
        
                $post_log = $post_log . "*************************************\r\n";
        
                $post_log = $post_log.file_get_contents( $oceanpayment_log_url . $filedate . ".log");
        
                $filename = fopen( $oceanpayment_log_url . $filedate . ".log", "r+" );
        
                fwrite($filename,$post_log);
        
                fclose($filename);
        
                fclose($newfile);
            }
            
            wp_send_json_success([
                'message' => __('订单创建成功', 'woocommerce'),
                'data' => $payment_config,
            ]);
            
        } catch (Exception $e) {
            wp_send_json_error([
                'message' => $e->getMessage()
            ]);
        }
    }
// 创建订单（为Apple Pay提供配置）
function wc_apple_pay_confirm_payment() {
    try {
            // 安全验证
            if (!wp_verify_nonce($_POST['security'],'oceanapplepayonepage',)) {
                throw new Exception(__('安全验证失败，请刷新页面重试', 'woocommerce'));
            };
            
            // 获取订单
            $order_id = absint($_POST['order_id']);
            $order = wc_get_order($order_id);
            
            if (!$order) {
                throw new Exception(__('订单不存在。', 'woocommerce'));
            }
            // 标记订单为已支付
            $order->payment_complete();
            $order->add_order_note('通过Apple Pay成功付款。');
            
            // 清空购物车
            WC()->cart->empty_cart();
            
            // 返回成功和重定向URL
            wp_send_json_success(array(
                'redirect_url' => $order->get_checkout_order_received_url()
            ));
            
        } catch (Exception $e) {
            wp_send_json_error([
                'message' => $e->getMessage()
            ]);
        };
}



add_action( 'woocommerce_blocks_loaded', 'wc_oceanapplepayonepage_register_order_approval_payment_method_type' );

function wc_oceanapplepayonepage_register_order_approval_payment_method_type() {

    // Check if the required class exists
    if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
        return;
    }

    // Include the custom Blocks Checkout class
    require_once plugin_dir_path(__FILE__) . 'oceanapplepayonepage-block.php';
    // Hook the registration function to the 'woocommerce_blocks_payment_method_type_registration' action
    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
            // Register an instance of My_Custom_Gateway_Blocks
            $payment_method_registry->register( new Oceanapplepayonepage_Gateway_Blocks );
        }
    );
}
