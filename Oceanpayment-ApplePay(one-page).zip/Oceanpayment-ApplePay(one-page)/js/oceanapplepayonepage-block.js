const oceanapplepayonepage_settings = window.wc.wcSettings.getSetting( 'oceanapplepayonepage_data', {} ); 

const oceanapplepayonepage_label = window.wp.htmlEntities.decodeEntities( oceanapplepayonepage_settings.title ) || window.wp.i18n.__( 'Oceanpayment applepayonepage Payment Gateway', 'oceanpayment-applepayonepage-gateway' );
const overlay_apple = document.getElementById('apple_order-loading-overlay');
const order_int = Math.floor(Math.random() * (99999999 - 10000000 + 1)) + 10000000;
const oceanapplepayonepage_Content = (props) => {
    var sandbox = true;
    if(oceanapplepayonepage_settings.submiturl == 'Production'){
        sandbox = '';
    }
    const script_html_apple = '$(function() {\n' +
        '               //onePageApplePay.validateResults(false);\n'+
        '                   \n'+
        '                    //如需修改支付语言，可传入语言代码\n' +
        '                    onePageApplePay.init("'+sandbox+'",{\n'+
        '                        cssUrl:"'+oceanapplepayonepage_settings.cssurl+'",\n'+
        '                        terminal:"'+oceanapplepayonepage_settings.terminal+'",\n'+
        '                        transactionInfo: { \n'+
        '                            orderCurrency:"'+oceanapplepayonepage_settings.currency+'",\n'+
        '                            orderAmount:"'+oceanapplepayonepage_settings.amount+'",\n'+
        '                            billCountry:"'+oceanapplepayonepage_settings.billingCountry+'",\n'+
        '                            orderNumber:"'+order_int+'",\n'+
        '                            billAddress:"'+oceanapplepayonepage_settings.site_url+'"\n'+
        '                            },\n'+
        '                            buttonStyle:{\n'+
        '                                buttonstyle:"'+oceanapplepayonepage_settings.buttonstyle+'",/*按钮颜色*/\n'+
        '                                type:"'+oceanapplepayonepage_settings.type+'",/*按钮类型*/\n'+
        '                            }\n' +
        '    }) \n'+
        '});\n'+
        '            var oceanpaymentApplePayCallBack = function(data){	\n'+
        '                if (data.code == 2) {\n'+
        '                    console.log("唤起按钮，调用支付");\n'+
        '                       // 触发结账流程\n'+
        '                    const orderData = collectappleOrderData();\n'+
        '                    if(orderData == 1){return }else{createWooCommerceappleOrder(orderData)};\n'+
        '                }else{\n'+
        '                    /*处理下单返回*/\n'+
        '                    appleorderCallback(data);\n'+
        '                }\n'+
        '            }';

    var text =  React.createElement("div", {id:'oceanapplepayonepage-onepage'},);
    
    const { eventRegistration, emitResponse } = props;
    const { onPaymentSetup } = eventRegistration;


    window.wp.element.useEffect(() => {

        const div = document.createElement('div');
        div.className='oceanpayment-applepayelement';
        div.id='oceanpayment-applepayelement';
        div.innerHTML = '';
        document.getElementById('oceanapplepayonepage-onepage').appendChild(div);
        //添加js
        const script = document.createElement('script');
        script.innerHTML = script_html_apple;

        document.getElementById('oceanapplepayonepage-onepage').appendChild(script);

    }, []);

    //加载Apple Pay按钮
    return text;
};

// 创建WooCommerce订单并获取Apple Pay配置
    function createWooCommerceappleOrder(orderData) {
        
        overlay_apple.style.display = 'flex';
        jQuery.ajax({
            url : oceanapplepayonepage_settings.apple_ajax,
            type : 'POST',
            dataType: 'json',
            data : {
                action : 'wc_applepayonepage_create_order',
                security : oceanapplepayonepage_settings.nonce,
                data : orderData
            },
            success : function( response ) {
                console.log(response);
                var formData = response.data.data;
                console.log(formData);
                //提交参数信息给Oceanpayment支付网关
                onePageApplePay.checkout(formData);
                
                
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log(jqXHR);
                console.log('Error: ' + textStatus);
            }
        });
    };
    
    function appleorderCallback(data){
        // 创建一个DOMParser对象
        const parser = new DOMParser();
         
        // 解析XML字符串
        const xmlDoc = parser.parseFromString(data, "text/xml");
         
        // 访问XML数据
        const order_number = xmlDoc.getElementsByTagName("order_number")[0].childNodes[0].nodeValue;
        const payment_status = xmlDoc.getElementsByTagName("payment_status")[0].childNodes[0].nodeValue;
        const payment_details = xmlDoc.getElementsByTagName("payment_details")[0].childNodes[0].nodeValue;
        
        //3D直接重定向
        if(xmlDoc.querySelector('pay_url') !== null){
            const pay_url = xmlDoc.getElementsByTagName("pay_url")[0].childNodes[0].nodeValue;
            window.location.href = pay_url;
        }else if(payment_status == 1 || payment_status == -1){
            jQuery.ajax({
                url : oceanapplepayonepage_settings.apple_ajax,
                type : 'POST',
                dataType: 'json',
                data : {
                    action : 'wc_apple_pay_confirm_payment',
                    security : oceanapplepayonepage_settings.nonce,
                    order_id : order_number
                },
                success : function( response ) {
                    console.log(response);
                    window.location.href = response.data.redirect_url;
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.log(jqXHR);
                    console.log('Error: ' + textStatus);
                }
            });
        }else{
            alert(payment_details);
        }
    }
function apple_error_notice(tip){
                    $('.woocommerce-error').remove();
                    const html = `
                        <ul class="woocommerce-error" role="alert">
                            <li>`+tip+`</li>
                        </ul>
                    `;
                    $('.woocommerce-checkout').prepend(html);
                    $('html, body').animate({
                        scrollTop: $('.woocommerce-error').offset().top - 100
                    }, 300);
}

function collectappleOrderData() {
                const first_name = document.getElementById('billing-first_name').value;
                const last_name = document.getElementById('billing-last_name').value;
                const email = document.getElementById('email').value;
                const phone = document.getElementById('billing-phone').value;
                const country = document.getElementById('billing-country').value;
                const state = document.getElementById('billing-state').value;
                const address_1 = document.getElementById('billing-address_1').value;
                const city = document.getElementById('billing-city').value;
                const postcode = document.getElementById('billing-postcode').value;
                if(!first_name){
                     apple_error_notice('First_name Not empty');
                    return '1';
                }else if(!last_name){
                    apple_error_notice('Last_name Not empty');
                    return '1';
                }else if(!email){
                    apple_error_notice('Email Not empty');
                    return '1';
                }else if(!phone){
                    apple_error_notice('Phone Not empty');
                    return '1';
                }else if(!country){
                    apple_error_notice('Country Not empty');
                    return '1';
                }else if(!state){
                    apple_error_notice('Country Not empty');
                    return '1';
                }else if(!address_1){
                    apple_error_notice('Country Not empty');
                    return '1';
                }else if(!city){
                    apple_error_notice('Country Not empty');
                    return '1';
                }else if(!postcode){
                    apple_error_notice('Country Not empty');
                    return '1';
                }else{
                    return {
                        billing_first_name: first_name,
                        billing_last_name: last_name,
                        billing_email: email,
                        billing_phone: phone,
                        billing_country: country,
                        billing_state: state,
                        billing_address_1: address_1,
                        billing_city: city,
                        billing_postcode: postcode,
                        payment_method: 'oceanapplepayonepage',
                    };
                }
            }


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;
    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanapplepayonepage-blocks-payment-method__label".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanapplepayonepage_Block_Gateway = {
    name: 'oceanapplepayonepage',
    label: React.createElement(I, {
        id: "oceanapplepayonepage",
        title: oceanapplepayonepage_settings.title,
        icons: oceanapplepayonepage_settings.icons
    }),

    // content: Object( window.wp.element.createElement )( oceanapplepayonepage_Content, null ),
    content: Object( window.wp.element.createElement )( oceanapplepayonepage_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanapplepayonepage_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanapplepayonepage_label,
    placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to pay', 'oceanpayment-applepayonepage-gateway' ),
    supports: {
        features: oceanapplepayonepage_settings.supports,
    },
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanapplepayonepage_Block_Gateway );