<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanapplepayonepage_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanapplepayonepage';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanapplepayonepage_settings', [] );
        $this->gateway = new WC_Gateway_Oceanapplepayonepage();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {
        wp_register_style('plugin_stylesheet_apple', plugin_dir_url(__FILE__) . 'css/oceanapplepay.css');
        wp_enqueue_style('plugin_stylesheet_apple');
        wp_register_script(
            'oceanapplepayonepage-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanapplepayonepage-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceanapplepayonepage-blocks-integration');
            
        }
        if (is_checkout()) {
            wp_enqueue_script(
                'op-apple-pay-jq',
                'https://secure.oceanpayment.com/pub/js/jquery/jq.js',
                [],
                null,
                true
            );
            wp_enqueue_script(
                'op-apple-pay-js',
                'https://secure.oceanpayment.com/pages/js/oceanpayment-applepay.js',
                [],
                null,
                true
            );
        }
        
        
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceanapplepayonepage-blocks-integration');
            
        }


        return [ 'oceanapplepayonepage-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'applepayonepage_icon',
            'alt' => 'Applepay One-Page',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/applepay.svg' , __FILE__ ) ),
        );
        $host = parse_url(get_site_url(), PHP_URL_HOST);
        $parts = explode('.', $host);
        if (is_checkout()){
            return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons,
            'submiturl'=>$this->gateway->submiturl??'',
            'cssurl'=>$this->gateway->cssurl??'',
            'currency'=>get_woocommerce_currency(),
            'amount'=>WC()->cart->get_total('value'),
            'billingCountry'=>WC()->customer->get_billing_country(),
            'site_url'=>$parts[count($parts)-2] . '.' . $parts[count($parts)-1],
            'buttonstyle'=>$this->gateway->buttonstyle,
            'type'=>$this->gateway->type,
            'nonce' => wp_create_nonce('oceanapplepayonepage'),
            'apple_ajax'=>admin_url('admin-ajax.php'),
            ];
        }else{
            return [
                'title' => $this->gateway->title,
                'description' => $this->gateway->description,
                'icons'=>$icons,
            ];
        }
    }

}
?>