
const oceanboost_settings = window.wc.wcSettings.getSetting( 'oceanboost_data', {} );


const oceanboost_label = window.wp.htmlEntities.decodeEntities( oceanboost_settings.title ) || window.wp.i18n.__( 'Oceanpayment Boost Payment Gateway', 'oceanpayment-boost-gateway' );




const oceanboost_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanboost_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanboost-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanboost_Block_Gateway = {
    name: 'oceanboost',

    label: React.createElement(I, {
        id: "oceanboost",
        title: oceanboost_settings.title,
        icons: oceanboost_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanboost_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanboost_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanboost_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-boost-gateway' ),
  /*  supports: {
        features: oceanboost_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanboost_Block_Gateway );