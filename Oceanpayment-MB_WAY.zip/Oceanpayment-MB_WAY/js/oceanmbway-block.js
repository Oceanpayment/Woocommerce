
const oceanmbway_settings = window.wc.wcSettings.getSetting( 'oceanmbway_data', {} );


const oceanmbway_label = window.wp.htmlEntities.decodeEntities( oceanmbway_settings.title ) || window.wp.i18n.__( 'Oceanpayment MBWay Payment Gateway', 'oceanpayment-mbway-gateway' );




const oceanmbway_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanmbway_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanmbway-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanmbway_Block_Gateway = {
    name: 'oceanmbway',

    label: React.createElement(I, {
        id: "oceanmbway",
        title: oceanmbway_settings.title,
        icons: oceanmbway_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanmbway_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanmbway_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanmbway_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-mbway-gateway' ),
    /*  supports: {
          features: oceanmbway_settings.supports,
      },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanmbway_Block_Gateway );