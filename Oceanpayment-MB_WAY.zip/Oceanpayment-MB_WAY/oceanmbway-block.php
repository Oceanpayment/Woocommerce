<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanmbway_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanmbway';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanmbway_settings', [] );
        $this->gateway = new WC_Gateway_Oceanmbway();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceanmbway-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanmbway-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {
            wp_set_script_translations( 'oceanmbway-blocks-integration');

        }


        return [ 'oceanmbway-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'mbway_icon',
            'alt' => 'mbway',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_mb_way.svg' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>