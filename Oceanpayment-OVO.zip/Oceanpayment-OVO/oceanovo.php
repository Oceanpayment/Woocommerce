<?php
/*
	Plugin Name: Oceanpayment OVO Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment OVO Gateway.
	Version: 6.0
	Author: Oceanpayment
	Requires at least: 4.0
	Tested up to: 6.1
    Text Domain: oceanpayment-ovo-gateway
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceanovo', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceanovo_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.0
 */
function woocommerce_oceanovo_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceanovo.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceanovo_add_gateway' );

} // End woocommerce_oceanovo_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.0
 */
function woocommerce_oceanovo_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceanovo';
	return $methods;
} // End woocommerce_oceanovo_add_gateway()