<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanovo_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanovo';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanovo_settings', [] );
        $this->gateway = new WC_Gateway_Oceanovo();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceanovo-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanovo-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceanovo-blocks-integration');
            
        }


        return [ 'oceanovo-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'ovo_icon',
            'alt' => 'OVO',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_ovo.png' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>