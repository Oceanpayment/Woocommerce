
const oceanovo_settings = window.wc.wcSettings.getSetting( 'oceanovo_data', {} );


const oceanovo_label = window.wp.htmlEntities.decodeEntities( oceanovo_settings.title ) || window.wp.i18n.__( 'Oceanpayment OVO Payment Gateway', 'oceanpayment-ovo-gateway' );




const oceanovo_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanovo_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanovo-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanovo_Block_Gateway = {
    name: 'oceanovo',

    label: React.createElement(I, {
        id: "oceanovo",
        title: oceanovo_settings.title,
        icons: oceanovo_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanovo_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanovo_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanovo_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-ovo-gateway' ),
  /*  supports: {
        features: oceanovo_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanovo_Block_Gateway );