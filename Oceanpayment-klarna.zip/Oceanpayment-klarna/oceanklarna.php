<?php
/*
	Plugin Name: Oceanpayment Klarna Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment Klarna Gateway.
	Version: 6.0
	Author: Oceanpayment
	Requires at least: 4.0
	Tested up to: 6.1
    Text Domain: oceanpayment-klarna-gateway
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceanklarna', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceanklarna_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.0
 */
function woocommerce_oceanklarna_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceanklarna.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceanklarna_add_gateway' );

} // End woocommerce_oceanklarna_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.0
 */
function woocommerce_oceanklarna_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceanklarna';
	return $methods;
} // End woocommerce_oceanklarna_add_gateway()