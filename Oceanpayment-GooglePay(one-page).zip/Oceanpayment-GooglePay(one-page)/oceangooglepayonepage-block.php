<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceangooglepayonepage_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceangooglepayonepage';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceangooglepayonepage_settings', [] );
        $this->gateway = new WC_Gateway_Oceangooglepayonepage();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {
        wp_register_style('plugin_stylesheet_google', plugin_dir_url(__FILE__) . 'css/oceangooglepay.css');
        wp_enqueue_style('plugin_stylesheet_google');
        wp_register_script(
            'oceangooglepayonepage-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceangooglepayonepage-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        wp_register_script(
            'oceangooglepayonepage-blocks-googlepayonepage',
            plugin_dir_url(__FILE__) . 'js/googlepayonepage.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceangooglepayonepage-blocks-integration');
            
        }
        if (is_checkout()) {
            wp_enqueue_script(
                    'op-google-pay-js',
                    'https://secure.oceanpayment.com/pages/js/oceanpayment-googlepay.js',
                    [],
                    null,
                    true
                );
            wp_enqueue_script(
                'op-google-pay-jq',
                'https://secure.oceanpayment.com/pub/js/jquery/jq.js',
                [],
                null,
                true
            );
        }
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceangooglepayonepage-blocks-integration');
            
        }


        return [ 'oceangooglepayonepage-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'googlepayonepage_icon',
            'alt' => 'Googlepay One-Page',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/googlepay.svg' , __FILE__ ) ),
        );

        if (is_checkout()){
            return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons,
            'submiturl'=>$this->gateway->submiturl,
            'cssurl'=>$this->gateway->cssurl??'',
            'currency'=>get_woocommerce_currency(),
            'amount'=>WC()->cart->get_total('value'),
            'billingCountry'=>WC()->customer->get_billing_country(),
            'buttonColor'=>$this->gateway->buttonColor,
            'buttonType'=>$this->gateway->buttonType,
            'buttonRadius'=>$this->gateway->buttonRadius,
            'buttonSizeMode'=>$this->gateway->buttonSizeMode,
            'buttonLocale'=>$this->gateway->buttonLocale,
            'nonce' => wp_create_nonce('oceangooglepayonepage'),
            'google_ajax'=>admin_url('admin-ajax.php'),
            ];
        }else{
            return [
                'title' => $this->gateway->title,
                'description' => $this->gateway->description,
                'icons'=>$icons,
                'submiturl'=>$this->gateway->submiturl,
                'cssurl'=>$this->gateway->cssurl??'',
                'sandbox'=>$this->gateway->sandbox??'',
            ];
        }
    }

}
?>