const oceangooglepayonepage_settings = window.wc.wcSettings.getSetting( 'oceangooglepayonepage_data', {} ); 

const oceangooglepayonepage_label = window.wp.htmlEntities.decodeEntities( oceangooglepayonepage_settings.title ) || window.wp.i18n.__( 'Oceanpayment googlepayonepage Payment Gateway', 'oceanpayment-googlepayonepage-gateway' );
const overlay_google = document.getElementById('google_order-loading-overlay');

const oceangooglepayonepage_Content = (props) => {
    var sandbox = true;
    if(oceangooglepayonepage_settings.submiturl == 'Production'){
        sandbox = '';
    }
    const script_html= '$(function() {\n' +
        '               //onePageGooglePay.validateResults(false);\n'+
        '                   \n'+
        '                    //如需修改支付语言，可传入语言代码\n' +
        '                    onePageGooglePay.init("'+sandbox+'",{\n'+
        '                        cssUrl:"'+oceangooglepayonepage_settings.cssurl+'",\n'+
        '                        transactionInfo: { \n'+
        '                            orderCurrency:"'+oceangooglepayonepage_settings.currency+'",\n'+
        '                            orderAmount:"'+oceangooglepayonepage_settings.amount+'",\n'+
        '                            billCountry:"'+oceangooglepayonepage_settings.billingCountry+'"\n'+
        '                            },\n'+
        '                            buttonStyle:{\n'+
        '                                buttonColor:"'+oceangooglepayonepage_settings.buttonColor+'",/*按钮颜色*/\n'+
        '                                buttonType:"'+oceangooglepayonepage_settings.buttonType+'",/*按钮类型*/\n'+
        '                                buttonRadius:"'+oceangooglepayonepage_settings.buttonRadius+'",/*圆角*/\n'+
        '                                buttonSizeMode:"'+oceangooglepayonepage_settings.buttonSizeMode+'",/*尺寸样式*/\n'+
        '                                buttonLocale:"'+oceangooglepayonepage_settings.buttonLocale+'"/*按钮语言*/\n'+
        '                            }\n' +
        '    }) \n'+
        '});\n'+
        '            var oceanpaymentGooglePayCallBack = function(data){	\n'+
        '                if (data.code == 2) {\n'+
        '                    console.log("唤起按钮，调用支付");\n'+
        '                       // 触发结账流程\n'+
        '                    const orderData = collectOrderData();\n'+
        '                    createWooCommerceOrder(orderData);\n'+
        '                }else{\n'+
        '                    /*处理下单返回*/\n'+
        '                    orderCallback(data);\n'+
        '                }\n'+
        '            }';

    var text =  React.createElement("div", {id:'oceangooglepayonepage-onepage'},);
    
    const { eventRegistration, emitResponse } = props;
    const { onPaymentSetup } = eventRegistration;


    window.wp.element.useEffect(() => {

        const div = document.createElement('div');
        div.className='oceanpayment-googlepayelement';
        div.id='oceanpayment-googlepayelement';
        div.innerHTML = '';
        document.getElementById('oceangooglepayonepage-onepage').appendChild(div);
        //添加js
        const script = document.createElement('script');
        script.innerHTML = script_html;

        document.getElementById('oceangooglepayonepage-onepage').appendChild(script);

    }, []);

    //加载Google Pay按钮
    return text;
};

// 创建WooCommerce订单并获取Google Pay配置
    function createWooCommerceOrder(orderData) {
        
        overlay_google.style.display = 'flex';
        jQuery.ajax({
            url : oceangooglepayonepage_settings.google_ajax,
            type : 'POST',
            dataType: 'json',
            data : {
                action : 'wc_googlepayonepage_create_order',
                security : oceangooglepayonepage_settings.nonce,
                data : orderData
            },
            success : function( response ) {
                console.log(response);
                var formData = response.data.data;
                console.log(formData);
                //提交参数信息给Oceanpayment支付网关
                onePageGooglePay.checkout(formData);
                
                
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log(jqXHR);
                console.log('Error: ' + textStatus);
            }
        });
    };
    
    function orderCallback(data){
        // 创建一个DOMParser对象
        const parser = new DOMParser();
         
        // 解析XML字符串
        const xmlDoc = parser.parseFromString(data, "text/xml");
         
        // 访问XML数据
        const order_number = xmlDoc.getElementsByTagName("order_number")[0].childNodes[0].nodeValue;
        const payment_status = xmlDoc.getElementsByTagName("payment_status")[0].childNodes[0].nodeValue;
        const payment_details = xmlDoc.getElementsByTagName("payment_details")[0].childNodes[0].nodeValue;
        
        //3D直接重定向
        if(xmlDoc.querySelector('pay_url') !== null){
            const pay_url = xmlDoc.getElementsByTagName("pay_url")[0].childNodes[0].nodeValue;
            window.location.href = pay_url;
        }else if(payment_status == 1 || payment_status == -1){
            jQuery.ajax({
                url : oceangooglepayonepage_settings.google_ajax,
                type : 'POST',
                dataType: 'json',
                data : {
                    action : 'wc_google_pay_confirm_payment',
                    security : oceangooglepayonepage_settings.nonce,
                    order_id : order_number,
                },
                success : function( response ) {
                    window.location.href = response.data.redirect_url;
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.log(jqXHR);
                    console.log('Error: ' + textStatus);
                }
            });

        }else{
            alert(payment_details);
        }
    }

function collectOrderData() {
                return {
                    billing_first_name: document.getElementById('billing-first_name').value,
                    billing_last_name: document.getElementById('billing-last_name').value,
                    billing_email: document.getElementById('email').value,
                    billing_phone: document.getElementById('billing-phone').value,
                    billing_country: document.getElementById('billing-country').value,
                    billing_state: document.getElementById('billing-state').value,
                    billing_address_1: document.getElementById('billing-address_1').value,
                    billing_city: document.getElementById('billing-city').value,
                    billing_postcode: document.getElementById('billing-postcode').value,
                    payment_method: 'oceangooglepayonepage',
                };
            }


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceangooglepayonepage-blocks-payment-method__label".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceangooglepayonepage_Block_Gateway = {
    name: 'oceangooglepayonepage',
    label: React.createElement(I, {
        id: "oceangooglepayonepage",
        title: oceangooglepayonepage_settings.title,
        icons: oceangooglepayonepage_settings.icons
    }),

    // content: Object( window.wp.element.createElement )( oceangooglepayonepage_Content, null ),
    content: Object( window.wp.element.createElement )( oceangooglepayonepage_Content, null ),
    edit: Object( window.wp.element.createElement )( oceangooglepayonepage_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceangooglepayonepage_label,
    placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to pay', 'oceanpayment-googlepayonepage-gateway' ),
    supports: {
        features: oceangooglepayonepage_settings.supports,
    },
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceangooglepayonepage_Block_Gateway );