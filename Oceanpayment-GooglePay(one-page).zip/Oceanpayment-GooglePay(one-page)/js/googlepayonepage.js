jQuery(document).ready(function($) {
    if (typeof google === 'undefined' || typeof google.payments === 'undefined') {
        console.error('Google Pay JS未加载');
        return;
    }

    const googlePayConfig = window.googlepayonepage_params || {};
    const paymentsClient = new google.payments.api.PaymentsClient({
        environment: googlePayConfig.environment || 'TEST'
    });

    // 检查是否支持Google Pay
    paymentsClient.isReadyToPay({
        apiVersion: 2,
        apiVersionMinor: 0,
        allowedPaymentMethods: getBasePaymentMethods()
    }).then(function(response) {
        if (response.result) {
            createGooglePayButton();
        } else {
            $('#googlepayonepage-button-container').hide();
        }
    }).catch(function(err) {
        console.error('Google Pay检查失败:', err);
    });

    function getBasePaymentMethods() {
        return [{
            type: 'CARD',
            parameters: {
                allowedAuthMethods: ['PAN_ONLY', 'CRYPTOGRAM_3DS'],
                allowedCardNetworks: ['AMEX', 'DISCOVER', 'JCB', 'MASTERCARD', 'VISA']
            },
            tokenizationSpecification: {
                type: 'PAYMENT_GATEWAY',
                parameters: getGatewayParameters()
            }
        }];
    }

    function getGatewayParameters() {
        switch(googlePayConfig.gateway) {
            case 'stripe':
                return {
                    'gateway': 'stripe',
                    'stripe:version': '2020-08-27',
                    'stripe:publishableKey': googlePayConfig.stripe_key
                };
            case 'braintree':
                return {
                    'gateway': 'braintree',
                    'braintree:apiVersion': 'v1',
                    'braintree:sdkVersion': '3.82.0',
                    'braintree:merchantId': googlePayConfig.braintree_merchant_id,
                    'braintree:clientKey': googlePayConfig.braintree_key
                };
            default:
                return {};
        }
    }

    function createGooglePayButton() {
        const button = paymentsClient.createButton({
            onClick: onGooglePayButtonClicked,
            buttonType: 'buy',
            buttonColor: 'black'
        });
        
        $('#googlepayonepage-button-container').html(button);
    }

    function onGooglePayButtonClicked() {
        const paymentDataRequest = {
            apiVersion: 2,
            apiVersionMinor: 0,
            allowedPaymentMethods: getBasePaymentMethods(),
            merchantInfo: {
                merchantId: googlePayConfig.merchant_id,
                merchantName: googlePayConfig.merchant_name
            },
            transactionInfo: {
                totalPriceStatus: 'FINAL',
                totalPrice: googlePayConfig.order_total,
                currencyCode: googlePayConfig.currency,
                countryCode: googlePayConfig.country
            }
        };

        paymentsClient.loadPaymentData(paymentDataRequest)
            .then(paymentData => processPaymentData(paymentData))
            .catch(err => handlePaymentError(err));
    }

    function processPaymentData(paymentData) {
        $('form.checkout').block({
            message: null,
            overlayCSS: {
                background: '#fff',
                opacity: 0.6
            }
        });

        const paymentToken = paymentData.paymentMethodData.tokenizationData.token;
        
        $.ajax({
            url: googlePayConfig.ajax_url,
            type: 'POST',
            data: {
                action: 'process_googlepayonepage_payment',
                payment_token: paymentToken,
                order_id: googlePayConfig.order_id,
                security: googlePayConfig.nonce
            },
            success: function(response) {
                if (response.success) {
                    window.location = response.redirect;
                } else {
                    $('#googlepayonepage-errors').text(response.message).show();
                    $('form.checkout').unblock();
                }
            },
            error: function() {
                $('#googlepayonepage-errors').text('支付处理失败').show();
                $('form.checkout').unblock();
            }
        });
    }

    function handlePaymentError(err) {
        console.error('Google Pay支付错误:', err);
        $('#googlepayonepage-errors').text('支付过程中发生错误: ' + err.statusMessage).show();
    }
});