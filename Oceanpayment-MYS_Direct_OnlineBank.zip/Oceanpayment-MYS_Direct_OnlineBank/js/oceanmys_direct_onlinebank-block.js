
const oceanmys_direct_onlinebank_settings = window.wc.wcSettings.getSetting( 'oceanmys_direct_onlinebank_data', {} );


const oceanmys_direct_onlinebank_label = window.wp.htmlEntities.decodeEntities( oceanmys_direct_onlinebank_settings.title ) || window.wp.i18n.__( 'Oceanpayment Naverpay Payment Gateway', 'oceanpayment-mys_direct_onlinebank-gateway' );




const oceanmys_direct_onlinebank_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanmys_direct_onlinebank_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanmys_direct_onlinebank-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanmys_direct_onlinebank_Block_Gateway = {
    name: 'oceanmys_direct_onlinebank',

    label: React.createElement(I, {
        id: "oceanmys_direct_onlinebank",
        title: oceanmys_direct_onlinebank_settings.title,
        icons: oceanmys_direct_onlinebank_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanmys_direct_onlinebank_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanmys_direct_onlinebank_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanmys_direct_onlinebank_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-mys_direct_onlinebank-gateway' ),
  /*  supports: {
        features: oceanmys_direct_onlinebank_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanmys_direct_onlinebank_Block_Gateway );