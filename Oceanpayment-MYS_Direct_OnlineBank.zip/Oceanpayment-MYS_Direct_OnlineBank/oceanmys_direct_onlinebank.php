<?php
/*
	Plugin Name: Oceanpayment  马来西亚网银转账| MYS_Direct_OnlineBank
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment  马来西亚网银转账| MYS_Direct_OnlineBank.
	Version: 1.0
	Author: Oceanpayment
	Requires at least: 1.0
	Tested up to: 1.0
    Text Domain: oceanpayment-mys_direct_onlinebank-gateway
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceanmys_direct_onlinebank', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceanmys_direct_onlinebank_init', 0 );

add_filter('woocommerce_payment_gateways', 'woocommerce_oceanmys_direct_onlinebank_add_gateway' );

/**
 * Initialize the gateway.
 *
 * @since 1.0
 */
function woocommerce_oceanmys_direct_onlinebank_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceanmys_direct_onlinebank.php' ) );


} // End woocommerce_oceanmys_direct_onlinebank_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.0
 */
function woocommerce_oceanmys_direct_onlinebank_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceanmys_direct_onlinebank';
	return $methods;
} // End woocommerce_oceanmys_direct_onlinebank_add_gateway()

/**
 * Custom function to declare compatibility with cart_checkout_blocks feature
 */
function wc_oceanmys_direct_onlinebank_declare_cart_checkout_blocks_compatibility() {
    // Check if the required class exists
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        // Declare compatibility for 'cart_checkout_blocks'
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
}
add_filter('woocommerce_gateway_icon', 'custom_payment_icon_by_country1', 10, 2);
function custom_payment_icon_by_country1($icon,$gateway_id) {
	// 只在结账页面应用
	if (!is_checkout() && !is_wc_endpoint_url('order-pay')) return $icon;

	switch ($gateway_id) {
		case 'oceanmys_direct_onlinebank':
			$src = plugins_url( 'images/op_MYS_Direct_OnlineBank.svg', __FILE__ );
			return "<img src=".$src." style='height:40px;'>";
			break;
	}

	return $icon;
}

//条件字段添加
add_filter('woocommerce_checkout_fields', 'add_conditional_checkout_fields_oceanmys_direct_onlinebank');

function add_conditional_checkout_fields_oceanmys_direct_onlinebank($fields) {
    // 添加条件字段
    $fields['billing']['mys_direct_onlinebank_pay_bankcode'] = array(
        'type'        => 'select',
        'label'       => __('bank', ''),
        'placeholder' => __('仅MYS_Direct_OnlineBank需要填写', ''),
        'required'    => false,
        'class'       => array('form-row-wide', 'form-row form-row-wide address-field update_totals_on_change thwcfd-required thwcfd-field-wrapper thwcfd-field-country validate-required'),
        'options'     => array(
            ''        => __('select ', ''),
            'FPX_MB2U'        => __('Maybank', ''),
            'FPX_CIMBCLICKS' => __('FPX CIMB', ''),
            'FPX_AMB' => __('FPX_AMB', ''),
            'FPX_HLB' => __('FPX_HLB', ''),
            'FPX_PBB'        => __('FPX_PBB', ''),
            'FPX_RHB' => __('FPX_RHB', ''),
            'FPX_BIMB' => __('FPX_BIMB', ''),
            'FPX_OCBC' => __('FPX_OCBC', ''),
            'FPX_SCB'        => __('FPX_SCB', ''),
            'FPX_ABB' => __('FPX_ABB', ''),
            'FPX_UOB' => __('FPX_UOB', ''),
            'FPX_ABMB' => __('FPX_ABMB', ''),
            'FPX_BSN'        => __('FPX_BSN', ''),
            'FPX_KFH' => __('FPX_KFH', ''),
            'FPX_BMMB' => __('FPX_BMMB', ''),
            'FPX_BKRM' => __('FPX_BKRM', ''),
            'FPX_HSBC' => __('FPX_HSBC', ''),
            'FPX_AGROBANK' => __('FPX_AGROBANK', ''),
        ),
        'priority'    => 120,
        'conditional' => array(
            'show_if' => 'fff', // 仅当支付方式为货到付款时显示
        ),
    );
    return $fields;
}


add_action('wp_footer', 'disable_mys_direct_onlinebank');
function disable_mys_direct_onlinebank() {
    if (!is_checkout()) return; // 仅作用于结账页面
    ?>
    <script type="text/javascript">
        window.addEventListener('load', function() {
            // 假设有一个选中的单选按钮
            if(document.querySelector('input[name="radio-control-wc-payment-method-options"]:checked')){
                var selectedValue = document.querySelector('input[name="radio-control-wc-payment-method-options"]:checked').value;
                if(selectedValue == 'oceanmys_direct_onlinebank' || selectedValue == 'oceanmys_direct_onlinebank'){
                    document.querySelector('.wc-block-components-select-input-namespace-mys_direct_onlinebank_pay_bankcode').style.display = 'block';
                }else{
					document.querySelector('.wc-block-components-select-input-namespace-mys_direct_onlinebank_pay_bankcode').style.display = 'none';
				}
            }

            if(document.querySelector('input[name="payment_method"]')){
                var selectedValue = document.querySelector('input[name="payment_method"]').value;
                console.log(selectedValue);
                if(selectedValue == 'oceanmys_direct_onlinebank' || selectedValue == 'oceanmys_direct_onlinebank'){
                    document.querySelector('#mys_direct_onlinebank_pay_bankcode_field').style.display = 'block';
                }else{
					document.querySelector('#mys_direct_onlinebank_pay_bankcode_field').style.display = 'none';
				}
            }

        })
        jQuery(document).ready(function($) {
            $(document.body).on('change', 'input[name="radio-control-wc-payment-method-options"]', function() {
                var paymentMethod = $(this).val();
                if(paymentMethod == 'oceanmys_direct_onlinebank' || paymentMethod == 'oceanmys_direct_onlinebank'){
                    document.querySelector('.wc-block-components-select-input-namespace-mys_direct_onlinebank_pay_bankcode').style.display = 'block';
                }else{
                    document.querySelector('.wc-block-components-select-input-namespace-mys_direct_onlinebank_pay_bankcode').style.display = 'none';
                }
            })

            $(document.body).on('change', 'input[name="payment_method"]', function() {
                var paymentMethod_traditional = $(this).val();
				console.log(paymentMethod_traditional);
                if(paymentMethod_traditional == 'oceanmys_direct_onlinebank' || paymentMethod_traditional == 'oceanmys_direct_onlinebank'){
                    document.querySelector('#mys_direct_onlinebank_pay_bankcode_field').style.display = 'block';
                }else{
                    document.querySelector('#mys_direct_onlinebank_pay_bankcode_field').style.display = 'none';
                }
            })
        })
    </script>
    <?php
}


add_action(
    'woocommerce_blocks_loaded',
    function() {
        woocommerce_register_additional_checkout_field(
            array(
                'id'            => 'namespace/mys_direct_onlinebank_pay_bankcode',
                'label'         => 'bank',
                'optionalLabel' => 'bank',
                'location'      => 'contact',
                'type'          => 'select',
                'options'  => [
                    [
                        'value' => 'FPX_MB2U',
                        'label' => 'FPX Maybank'
                    ],
                    [
                        'value' => 'FPX_CIMBCLICKS',
                        'label' => 'FPX CIMB'
                    ],
                    [
                        'value' => 'FPX_AMB',
                        'label' => 'FPX_AMB'
                    ],
                    [
                        'value' => 'FPX_HLB',
                        'label' => 'FPX_HLB'
                    ],
                    [
                        'value' => 'FPX_PBB',
                        'label' => 'FPX_PBB'
                    ],
                    [
                        'value' => 'FPX_RHB',
                        'label' => 'FPX_RHB'
                    ],
                    [
                        'value' => 'FPX_BIMB',
                        'label' => 'FPX_BIMB'
                    ],
                    [
                        'value' => 'FPX_OCBC',
                        'label' => 'FPX_OCBC'
                    ],
                    [
                        'value' => 'FPX_SCB',
                        'label' => 'FPX_SCB'
                    ],
                    [
                        'value' => 'FPX_ABB',
                        'label' => 'FPX_ABB'
                    ],
                    [
                        'value' => 'FPX_UOB',
                        'label' => 'FPX_UOB'
                    ],
                    [
                        'value' => 'FPX_ABMB',
                        'label' => 'FPX_ABMB'
                    ],
                    [
                        'value' => 'FPX_BSN',
                        'label' => 'FPX_BSN'
                    ],
                    [
                        'value' => 'FPX_KFH',
                        'label' => 'FPX_KFH'
                    ],
                    [
                        'value' => 'FPX_BMMB',
                        'label' => 'FPX_BMMB'
                    ],
                    [
                        'value' => 'FPX_BKRM',
                        'label' => 'FPX_BKRM'
                    ],
                    [
                        'value' => 'FPX_HSBC',
                        'label' => 'FPX_HSBC'
                    ],
                    [
                        'value' => 'FPX_AGROBANK',
                        'label' => 'FPX_AGROBANK'
                    ],
                ]
            ),
    );
    }
);



// Hook the custom function to the 'before_woocommerce_init' action
add_action('before_woocommerce_init', 'wc_oceanmys_direct_onlinebank_declare_cart_checkout_blocks_compatibility');


add_action( 'woocommerce_blocks_loaded', 'wc_oceanmys_direct_onlinebank_register_order_approval_payment_method_type' );

function wc_oceanmys_direct_onlinebank_register_order_approval_payment_method_type() {

    // Check if the required class exists
    if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
        return;
    }

    // Include the custom Blocks Checkout class
    require_once plugin_dir_path(__FILE__) . 'oceanmys_direct_onlinebank-block.php';
    // Hook the registration function to the 'woocommerce_blocks_payment_method_type_registration' action
    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
            // Register an instance of My_Custom_Gateway_Blocks
            $payment_method_registry->register( new Oceanmys_direct_onlinebank_Gateway_Blocks );
        }
    );
}
