<?php
/*
	Plugin Name: Oceanpayment  KOR_SAMSUNGPAY Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment  KOR_SAMSUNGPAY Gateway.
	Version: 1.0
	Author: Oceanpayment
	Requires at least: 1.0
	Tested up to: 1.0
    Text Domain: oceanpayment-korsamsungpay-gateway
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceankorsamsungpay', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceankorsamsungpay_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.0
 */
function woocommerce_oceankorsamsungpay_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceankorsamsungpay.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceankorsamsungpay_add_gateway' );

} // End woocommerce_oceankorsamsungpay_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.0
 */
function woocommerce_oceankorsamsungpay_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceankorsamsungpay';
	return $methods;
} // End woocommerce_oceankorsamsungpay_add_gateway()