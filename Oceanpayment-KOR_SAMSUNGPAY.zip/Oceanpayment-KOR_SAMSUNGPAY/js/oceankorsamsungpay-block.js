
const oceankorsamsungpay_settings = window.wc.wcSettings.getSetting( 'oceankorsamsungpay_data', {} );


const oceankorsamsungpay_label = window.wp.htmlEntities.decodeEntities( oceankorsamsungpay_settings.title ) || window.wp.i18n.__( 'Oceanpayment KOR SAMSUNGPAY Payment Gateway', 'oceanpayment-korsamsungpay-gateway' );




const oceankorsamsungpay_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceankorsamsungpay_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceankorsamsungpay-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceankorsamsungpay_Block_Gateway = {
    name: 'oceankorsamsungpay',

    label: React.createElement(I, {
        id: "oceankorsamsungpay",
        title: oceankorsamsungpay_settings.title,
        icons: oceankorsamsungpay_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceankorsamsungpay_Content, null ),
    edit: Object( window.wp.element.createElement )( oceankorsamsungpay_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceankorsamsungpay_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-korsamsungpay-gateway' ),
  /*  supports: {
        features: oceankorsamsungpay_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceankorsamsungpay_Block_Gateway );