
const oceancreditcardmx_settings = window.wc.wcSettings.getSetting( 'oceancreditcardmx_data', {} );


const oceancreditcardmx_label = window.wp.htmlEntities.decodeEntities( oceancreditcardmx_settings.title ) || window.wp.i18n.__( 'Oceanpayment Creditcard MX Payment Gateway', 'oceanpayment-creditcardmx-gateway' );




const oceancreditcardmx_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceancreditcardmx_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;
    return React.createElement("div", {
        className: "wc-oceancreditcardmx-blocks-payment-method__label ".concat(a)
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceancreditcardmx_Block_Gateway = {
    name: 'oceancreditcardmx',

    label: React.createElement(I, {
        id: "oceancreditcardmx",
        title: oceancreditcardmx_settings.title,
        icons: oceancreditcardmx_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceancreditcardmx_Content, null ),
    edit: Object( window.wp.element.createElement )( oceancreditcardmx_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceancreditcardmx_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to pay', 'oceanpayment-creditcardmx-gateway' ),
  /*  supports: {
        features: oceancreditcardmx_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceancreditcardmx_Block_Gateway );