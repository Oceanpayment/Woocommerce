<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanservipag_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanservipag';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanservipag_settings', [] );
        $this->gateway = new WC_Gateway_Oceanservipag();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceanservipag-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanservipag-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceanservipag-blocks-integration');
            
        }


        return [ 'oceanservipag-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'servipag_icon',
            'alt' => 'Servipag',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_servipag.png' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>