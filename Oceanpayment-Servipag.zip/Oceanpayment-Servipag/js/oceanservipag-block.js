
const oceanservipag_settings = window.wc.wcSettings.getSetting( 'oceanservipag_data', {} );


const oceanservipag_label = window.wp.htmlEntities.decodeEntities( oceanservipag_settings.title ) || window.wp.i18n.__( 'Oceanpayment Servipag Payment Gateway', 'oceanpayment-servipag-gateway' );




const oceanservipag_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanservipag_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanservipag-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanservipag_Block_Gateway = {
    name: 'oceanservipag',

    label: React.createElement(I, {
        id: "oceanservipag",
        title: oceanservipag_settings.title,
        icons: oceanservipag_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanservipag_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanservipag_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanservipag_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-servipag-gateway' ),
  /*  supports: {
        features: oceanservipag_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanservipag_Block_Gateway );