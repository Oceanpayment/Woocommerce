
const oceandana_settings = window.wc.wcSettings.getSetting( 'oceandana_data', {} );


const oceandana_label = window.wp.htmlEntities.decodeEntities( oceandana_settings.title ) || window.wp.i18n.__( 'Oceanpayment DANA Payment Gateway', 'oceanpayment-dana-gateway' );




const oceandana_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceandana_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceandana-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceandana_Block_Gateway = {
    name: 'oceandana',

    label: React.createElement(I, {
        id: "oceandana",
        title: oceandana_settings.title,
        icons: oceandana_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceandana_Content, null ),
    edit: Object( window.wp.element.createElement )( oceandana_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceandana_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-dana-gateway' ),
    /*  supports: {
          features: oceandana_settings.supports,
      },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceandana_Block_Gateway );