<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceangcash_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceangcash';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceangcash_settings', [] );
        $this->gateway = new WC_Gateway_Oceangcash();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceangcash-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceangcash-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceangcash-blocks-integration');
            
        }


        return [ 'oceangcash-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'gcash_icon',
            'alt' => 'GCash',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_gcash.png' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>