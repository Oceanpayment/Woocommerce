
const oceangcash_settings = window.wc.wcSettings.getSetting( 'oceangcash_data', {} );


const oceangcash_label = window.wp.htmlEntities.decodeEntities( oceangcash_settings.title ) || window.wp.i18n.__( 'Oceanpayment GCash Payment Gateway', 'oceanpayment-gcash-gateway' );




const oceangcash_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceangcash_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceangcash-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceangcash_Block_Gateway = {
    name: 'oceangcash',

    label: React.createElement(I, {
        id: "oceangcash",
        title: oceangcash_settings.title,
        icons: oceangcash_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceangcash_Content, null ),
    edit: Object( window.wp.element.createElement )( oceangcash_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceangcash_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-gcash-gateway' ),
  /*  supports: {
        features: oceangcash_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceangcash_Block_Gateway );