<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanbronlinebank_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanbronlinebank';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanbronlinebank_settings', [] );
        $this->gateway = new WC_Gateway_Oceanbronlinebank();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceanbronlinebank-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanbronlinebank-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceanbronlinebank-blocks-integration');
            
        }


        return [ 'oceanbronlinebank-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'bronlinebank_icon',
            'alt' => 'BR_OB',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_br_ob.png' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>