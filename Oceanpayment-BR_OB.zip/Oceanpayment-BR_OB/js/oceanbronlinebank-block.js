
const oceanbronlinebank_settings = window.wc.wcSettings.getSetting( 'oceanbronlinebank_data', {} );


const oceanbronlinebank_label = window.wp.htmlEntities.decodeEntities( oceanbronlinebank_settings.title ) || window.wp.i18n.__( 'Oceanpayment BR_OB Payment Gateway', 'oceanpayment-bronlinebank-gateway' );




const oceanbronlinebank_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanbronlinebank_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanbronlinebank-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanbronlinebank_Block_Gateway = {
    name: 'oceanbronlinebank',

    label: React.createElement(I, {
        id: "oceanbronlinebank",
        title: oceanbronlinebank_settings.title,
        icons: oceanbronlinebank_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanbronlinebank_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanbronlinebank_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanbronlinebank_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-bronlinebank-gateway' ),
  /*  supports: {
        features: oceanbronlinebank_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanbronlinebank_Block_Gateway );