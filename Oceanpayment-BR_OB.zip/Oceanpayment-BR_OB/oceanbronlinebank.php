<?php
/*
	Plugin Name: WooCommerce Oceanpayment Brazil OnlineBank Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment Brazil OnlineBank Gateway.
	Version: 1.0
	Author: Oceanpayment
	Requires at least: 1.0
	Tested up to: 1.0
    Text Domain: oceanpayment-brob-gateway
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceanbronlinebank', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceanbronlinebank_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.0
 */
function woocommerce_oceanbronlinebank_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceanbronlinebank.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceanbronlinebank_add_gateway' );

} // End woocommerce_oceanbronlinebank_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.0
 */
function woocommerce_oceanbronlinebank_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceanbronlinebank';
	return $methods;
} // End woocommerce_oceanbronlinebank_add_gateway()

/**
 * Custom function to declare compatibility with cart_checkout_blocks feature
 */
function wc_oceanbronlinebank_declare_cart_checkout_blocks_compatibility() {
    // Check if the required class exists
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        // Declare compatibility for 'cart_checkout_blocks'
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
}
// Hook the custom function to the 'before_woocommerce_init' action
add_action('before_woocommerce_init', 'wc_oceanbronlinebank_declare_cart_checkout_blocks_compatibility');


add_action( 'woocommerce_blocks_loaded', 'wc_oceanbronlinebank_register_order_approval_payment_method_type' );

add_filter( 'woocommerce_checkout_fields' , 'custom_override_checkout_fields' );

add_action(
    'woocommerce_blocks_loaded',
    function() {
        woocommerce_register_additional_checkout_field(
            array(
                'id'            => 'namespace/pay_cpf',
                'label'         => 'CPF',
                'optionalLabel' => 'CPF',
                'location'      => 'contact',
                'required'      => false,
                'attributes'    => array(
//                    'pattern'          => '[0-9]{11}',
                    'maxLength'          => '11', // A 5-character string of capital letters and numbers.
                ),
            ),
            );
    }
);

add_action(
    'woocommerce_blocks_loaded',
    function() {
        woocommerce_register_additional_checkout_field(
            array(
                'id'            => 'namespace/pay_bankcode',
                'label'         => 'pay_bankCode',
                'optionalLabel' => 'pay_bankCode',
                'location'      => 'contact',
                'type'          => 'select',
                'required'      => false,
                'attributes'    => array(),
                'options'       => [
                    [
                        'value' => 'I',
                        'label' => 'Itau'
                    ],
                    [
                        'value' => 'BB',
                        'label' => 'Banco do Brasil'
                    ],
                    [
                        'value' => 'B',
                        'label' => 'Bradesco'
                    ],
                    [
                        'value' => 'CA',
                        'label' => 'Caixa'
                    ],
                    [
                        'value' => 'SB',
                        'label' => 'Santander'
                    ]]
            )
        );
    }
);


function wc_oceanbronlinebank_register_order_approval_payment_method_type() {

    // Check if the required class exists
    if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
        return;
    }

    // Include the custom Blocks Checkout class
    require_once plugin_dir_path(__FILE__) . 'oceanbronlinebank-block.php';
    // Hook the registration function to the 'woocommerce_blocks_payment_method_type_registration' action
    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
            // Register an instance of My_Custom_Gateway_Blocks
            $payment_method_registry->register( new Oceanbronlinebank_Gateway_Blocks );
        }
    );
}