<?php
/*
	Plugin Name: WooCommerce Oceanpayment Brazil OnlineBank Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment Brazil OnlineBank Gateway.
	Version: 1.0
	Author: Oceanpayment
	Requires at least: 1.0
	Tested up to: 1.0
    Text Domain: oceanpayment-brob-gateway
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceanbronlinebank', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceanbronlinebank_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.0
 */
function woocommerce_oceanbronlinebank_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceanbronlinebank.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceanbronlinebank_add_gateway' );

} // End woocommerce_oceanbronlinebank_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.0
 */
function woocommerce_oceanbronlinebank_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceanbronlinebank';
	return $methods;
} // End woocommerce_oceanbronlinebank_add_gateway()