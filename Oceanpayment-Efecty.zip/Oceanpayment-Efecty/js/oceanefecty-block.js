
const oceanefecty_settings = window.wc.wcSettings.getSetting( 'oceanefecty_data', {} );


const oceanefecty_label = window.wp.htmlEntities.decodeEntities( oceanefecty_settings.title ) || window.wp.i18n.__( 'Oceanpayment Efecty Payment Gateway', 'oceanpayment-efecty-gateway' );




const oceanefecty_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanefecty_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanefecty-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanefecty_Block_Gateway = {
    name: 'oceanefecty',

    label: React.createElement(I, {
        id: "oceanefecty",
        title: oceanefecty_settings.title,
        icons: oceanefecty_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanefecty_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanefecty_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanefecty_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-efecty-gateway' ),
  /*  supports: {
        features: oceanefecty_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanefecty_Block_Gateway );