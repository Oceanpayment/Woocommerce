<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanefecty_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanefecty';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanefecty_settings', [] );
        $this->gateway = new WC_Gateway_Oceanefecty();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceanefecty-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanefecty-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceanefecty-blocks-integration');
            
        }


        return [ 'oceanefecty-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'efecty_icon',
            'alt' => 'Efecty',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_efecty.png' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>