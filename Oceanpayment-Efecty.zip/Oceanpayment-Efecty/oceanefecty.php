<?php
/*
	Plugin Name: WooCommerce Oceanpayment Efecty Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment Efecty Gateway.
	Version: 1.0
	Author: Oceanpayment
	Requires at least: 1.0
	Tested up to: 1.0
    Text Domain: oceanpayment-efecty-gateway
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceanefecty', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceanefecty_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.0
 */
function woocommerce_oceanefecty_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceanefecty.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceanefecty_add_gateway' );

} // End woocommerce_oceanefecty_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.0
 */
function woocommerce_oceanefecty_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceanefecty';
	return $methods;
} // End woocommerce_oceanefecty_add_gateway()

/**
 * Custom function to declare compatibility with cart_checkout_blocks feature
 */
function wc_oceanefecty_declare_cart_checkout_blocks_compatibility() {
    // Check if the required class exists
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        // Declare compatibility for 'cart_checkout_blocks'
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
}
// Hook the custom function to the 'before_woocommerce_init' action
add_action('before_woocommerce_init', 'wc_oceanefecty_declare_cart_checkout_blocks_compatibility');


add_action( 'woocommerce_blocks_loaded', 'wc_oceanefecty_register_order_approval_payment_method_type' );

add_action(
    'woocommerce_blocks_loaded',
    function() {
        woocommerce_register_additional_checkout_field(
            array(
                'id'            => 'namespace/pay_cpf',
                'label'         => 'CPF',
                'optionalLabel' => 'CPF',
                'location'      => 'address',
                'required'      => false,
                'attributes'    => array(
//                    'pattern'          => '[0-9]{11}',
                    'maxLength'          => '11', // A 5-character string of capital letters and numbers.
                ),
            ),
            );
    }
);

function wc_oceanefecty_register_order_approval_payment_method_type() {

    // Check if the required class exists
    if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
        return;
    }

    // Include the custom Blocks Checkout class
    require_once plugin_dir_path(__FILE__) . 'oceanefecty-block.php';
    // Hook the registration function to the 'woocommerce_blocks_payment_method_type_registration' action
    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
            // Register an instance of My_Custom_Gateway_Blocks
            $payment_method_registry->register( new Oceanefecty_Gateway_Blocks );
        }
    );
}