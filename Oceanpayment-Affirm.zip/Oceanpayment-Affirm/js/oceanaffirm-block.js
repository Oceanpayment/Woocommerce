
const oceanaffirm_settings = window.wc.wcSettings.getSetting( 'oceanaffirm_data', {} );


const oceanaffirm_label = window.wp.htmlEntities.decodeEntities( oceanaffirm_settings.title ) || window.wp.i18n.__( 'Oceanpayment Affirm Payment Gateway', 'oceanpayment-affirm-gateway' );




const oceanaffirm_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanaffirm_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanaffirm-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanaffirm_Block_Gateway = {
    name: 'oceanaffirm',

    label: React.createElement(I, {
        id: "oceanaffirm",
        title: oceanaffirm_settings.title,
        icons: oceanaffirm_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanaffirm_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanaffirm_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanaffirm_label,
  /*  supports: {
        features: oceanaffirm_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanaffirm_Block_Gateway );