
const oceankorssgpay_settings = window.wc.wcSettings.getSetting( 'oceankorssgpay_data', {} );


const oceankorssgpay_label = window.wp.htmlEntities.decodeEntities( oceankorssgpay_settings.title ) || window.wp.i18n.__( 'Oceanpayment SSGPay Payment Gateway', 'oceanpayment-korssgpay-gateway' );




const oceankorssgpay_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceankorssgpay_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceankorssgpay-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceankorssgpay_Block_Gateway = {
    name: 'oceankorssgpay',

    label: React.createElement(I, {
        id: "oceankorssgpay",
        title: oceankorssgpay_settings.title,
        icons: oceankorssgpay_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceankorssgpay_Content, null ),
    edit: Object( window.wp.element.createElement )( oceankorssgpay_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceankorssgpay_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-korssgpay-gateway' ),
  /*  supports: {
        features: oceankorssgpay_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceankorssgpay_Block_Gateway );