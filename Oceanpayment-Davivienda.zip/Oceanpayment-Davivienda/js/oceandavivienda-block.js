
const oceandavivienda_settings = window.wc.wcSettings.getSetting( 'oceandavivienda_data', {} );


const oceandavivienda_label = window.wp.htmlEntities.decodeEntities( oceandavivienda_settings.title ) || window.wp.i18n.__( 'Oceanpayment Davivienda Payment Gateway', 'oceanpayment-davivienda-gateway' );




const oceandavivienda_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceandavivienda_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceandavivienda-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceandavivienda_Block_Gateway = {
    name: 'oceandavivienda',

    label: React.createElement(I, {
        id: "oceandavivienda",
        title: oceandavivienda_settings.title,
        icons: oceandavivienda_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceandavivienda_Content, null ),
    edit: Object( window.wp.element.createElement )( oceandavivienda_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceandavivienda_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-davivienda-gateway' ),
  /*  supports: {
        features: oceandavivienda_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceandavivienda_Block_Gateway );