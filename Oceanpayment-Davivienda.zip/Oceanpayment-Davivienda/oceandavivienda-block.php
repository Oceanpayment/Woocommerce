<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceandavivienda_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceandavivienda';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceandavivienda_settings', [] );
        $this->gateway = new WC_Gateway_Oceandavivienda();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceandavivienda-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceandavivienda-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceandavivienda-blocks-integration');
            
        }


        return [ 'oceandavivienda-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'davivienda_icon',
            'alt' => 'Davivienda',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_davivienda.png' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>