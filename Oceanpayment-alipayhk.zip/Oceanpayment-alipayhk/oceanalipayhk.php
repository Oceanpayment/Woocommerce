<?php
/*
	Plugin Name: WooCommerce Oceanpayment alipayhk Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment alipayhk Gateway.
	Version: 1.2
	Author: Oceanpayment
	Author URI: http://www.oceanpayment.com/
	Requires at least: 1.0
	Tested up to: 1.0
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceanalipayhk', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceanalipayhk_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.2
 */
function woocommerce_oceanalipayhk_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceanalipayhk.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceanalipayhk_add_gateway' );

} // End woocommerce_oceanalipayhk_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.2
 */
function woocommerce_oceanalipayhk_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceanalipayhk';
	return $methods;
} // End woocommerce_oceanalipayhk_add_gateway()