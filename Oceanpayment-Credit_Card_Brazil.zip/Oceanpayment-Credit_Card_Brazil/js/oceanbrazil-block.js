
const oceanbrazil_settings = window.wc.wcSettings.getSetting( 'oceanbrazil_data', {} );


const oceanbrazil_label = window.wp.htmlEntities.decodeEntities( oceanbrazil_settings.title ) || window.wp.i18n.__( 'Oceanpayment Credit Card Brazil Payment Gateway', 'oceanpayment-brazil-gateway' );




const oceanbrazil_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanbrazil_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanbrazil-blocks-payment-method__label ".concat(a),
        // style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanbrazil_Block_Gateway = {
    name: 'oceanbrazil',

    label: React.createElement(I, {
        id: "oceanbrazil",
        title: oceanbrazil_settings.title,
        icons: oceanbrazil_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanbrazil_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanbrazil_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanbrazil_label,
    placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-brazil-gateway' ),
  /*  supports: {
        features: oceanbrazil_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanbrazil_Block_Gateway );