<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanbrazil_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanbrazil';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanbrazil_settings', [] );
        $this->gateway = new WC_Gateway_Oceanbrazil();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceanbrazil-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanbrazil-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceanbrazil-blocks-integration');
            
        }


        return [ 'oceanbrazil-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icon_arr = ['VISA','Maestro','American','Diners','Discover','ebanx','aura','Elo'];
        foreach ($icon_arr as $vo) {
            $icons[] = array(
                'id' => $vo . '_icon',
                'alt' => $vo,
                'src' => WC_HTTPS::force_https_url(plugins_url('images/' . $vo . '.png', __FILE__))
            );
        }
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>