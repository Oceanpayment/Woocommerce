
const oceanpayu_settings = window.wc.wcSettings.getSetting( 'oceanpayu_data', {} );


const oceanpayu_label = window.wp.htmlEntities.decodeEntities( oceanpayu_settings.title ) || window.wp.i18n.__( 'Oceanpayment PayU Payment Gateway', 'oceanpayment-payu-gateway' );




const oceanpayu_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanpayu_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanpayu-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanpayu_Block_Gateway = {
    name: 'oceanpayu',

    label: React.createElement(I, {
        id: "oceanpayu",
        title: oceanpayu_settings.title,
        icons: oceanpayu_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanpayu_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanpayu_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanpayu_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-payu-gateway' ),
  /*  supports: {
        features: oceanpayu_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanpayu_Block_Gateway );