<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanjeniuspay_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanjeniuspay';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanjeniuspay_settings', [] );
        $this->gateway = new WC_Gateway_Oceanjeniuspay();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceanjeniuspay-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanjeniuspay-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceanjeniuspay-blocks-integration');
            
        }


        return [ 'oceanjeniuspay-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'jeniuspay_icon',
            'alt' => 'JeniusPay',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_JeniusPay.png' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>