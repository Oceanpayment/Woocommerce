
const oceanjeniuspay_settings = window.wc.wcSettings.getSetting( 'oceanjeniuspay_data', {} );


const oceanjeniuspay_label = window.wp.htmlEntities.decodeEntities( oceanjeniuspay_settings.title ) || window.wp.i18n.__( 'Oceanpayment JeniusPay Payment Gateway', 'oceanpayment-jeniuspay-gateway' );




const oceanjeniuspay_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanjeniuspay_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanjeniuspay-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanjeniuspay_Block_Gateway = {
    name: 'oceanjeniuspay',

    label: React.createElement(I, {
        id: "oceanjeniuspay",
        title: oceanjeniuspay_settings.title,
        icons: oceanjeniuspay_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanjeniuspay_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanjeniuspay_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanjeniuspay_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-jeniuspay-gateway' ),
  /*  supports: {
        features: oceanjeniuspay_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanjeniuspay_Block_Gateway );