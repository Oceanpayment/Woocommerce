
const oceantouchngo_settings = window.wc.wcSettings.getSetting( 'oceantouchngo_data', {} );


const oceantouchngo_label = window.wp.htmlEntities.decodeEntities( oceantouchngo_settings.title ) || window.wp.i18n.__( 'Oceanpayment TouchnGo Payment Gateway', 'oceanpayment-touchngo-gateway' );




const oceantouchngo_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceantouchngo_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceantouchngo-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceantouchngo_Block_Gateway = {
    name: 'oceantouchngo',

    label: React.createElement(I, {
        id: "oceantouchngo",
        title: oceantouchngo_settings.title,
        icons: oceantouchngo_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceantouchngo_Content, null ),
    edit: Object( window.wp.element.createElement )( oceantouchngo_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceantouchngo_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-touchngo-gateway' ),
  /*  supports: {
        features: oceantouchngo_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceantouchngo_Block_Gateway );