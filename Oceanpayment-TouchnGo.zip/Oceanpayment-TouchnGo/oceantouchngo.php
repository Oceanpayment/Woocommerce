<?php
/*
	Plugin Name: WooCommerce Oceanpayment TouchnGo Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment TouchnGo Gateway.
	Version: 1.2
	Author: Oceanpayment
	Author URI: http://www.oceanpayment.com/
	Requires at least: 1.0
	Tested up to: 1.0
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceantouchngo', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceantouchngo_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.2
 */
function woocommerce_oceantouchngo_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceantouchngo.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceantouchngo_add_gateway' );

} // End woocommerce_oceantouchngo_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.2
 */
function woocommerce_oceantouchngo_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceantouchngo';
	return $methods;
} // End woocommerce_oceantouchngo_add_gateway()