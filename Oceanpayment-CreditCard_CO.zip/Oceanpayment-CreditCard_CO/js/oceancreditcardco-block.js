
const oceancreditcardco_settings = window.wc.wcSettings.getSetting( 'oceancreditcardco_data', {} );


const oceancreditcardco_label = window.wp.htmlEntities.decodeEntities( oceancreditcardco_settings.title ) || window.wp.i18n.__( 'Oceanpayment Creditcard CO Payment Gateway', 'oceanpayment-creditcardco-gateway' );




const oceancreditcardco_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceancreditcardco_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;
    return React.createElement("div", {
        className: "wc-oceancreditcardco-blocks-payment-method__label ".concat(a)
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceancreditcardco_Block_Gateway = {
    name: 'oceancreditcardco',

    label: React.createElement(I, {
        id: "oceancreditcardco",
        title: oceancreditcardco_settings.title,
        icons: oceancreditcardco_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceancreditcardco_Content, null ),
    edit: Object( window.wp.element.createElement )( oceancreditcardco_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceancreditcardco_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to pay', 'oceanpayment-creditcardco-gateway' ),
  /*  supports: {
        features: oceancreditcardco_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceancreditcardco_Block_Gateway );