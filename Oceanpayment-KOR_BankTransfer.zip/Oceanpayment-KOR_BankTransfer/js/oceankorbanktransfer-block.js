
const oceankorbanktransfer_settings = window.wc.wcSettings.getSetting( 'oceankorbanktransfer_data', {} );


const oceankorbanktransfer_label = window.wp.htmlEntities.decodeEntities( oceankorbanktransfer_settings.title ) || window.wp.i18n.__( 'Oceanpayment KOR_BankTransfer Payment Gateway', 'oceanpayment-korbanktransfer-gateway' );




const oceankorbanktransfer_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceankorbanktransfer_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceankorbanktransfer-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceankorbanktransfer_Block_Gateway = {
    name: 'oceankorbanktransfer',

    label: React.createElement(I, {
        id: "oceankorbanktransfer",
        title: oceankorbanktransfer_settings.title,
        icons: oceankorbanktransfer_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceankorbanktransfer_Content, null ),
    edit: Object( window.wp.element.createElement )( oceankorbanktransfer_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceankorbanktransfer_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-korbanktransfer-gateway' ),
  /*  supports: {
        features: oceankorbanktransfer_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceankorbanktransfer_Block_Gateway );