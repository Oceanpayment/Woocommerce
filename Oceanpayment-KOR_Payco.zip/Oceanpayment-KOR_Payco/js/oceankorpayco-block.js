
const oceankorpayco_settings = window.wc.wcSettings.getSetting( 'oceankorpayco_data', {} );


const oceankorpayco_label = window.wp.htmlEntities.decodeEntities( oceankorpayco_settings.title ) || window.wp.i18n.__( 'Oceanpayment Payco Payment Gateway', 'oceanpayment-korpayco-gateway' );




const oceankorpayco_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceankorpayco_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceankorpayco-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceankorpayco_Block_Gateway = {
    name: 'oceankorpayco',

    label: React.createElement(I, {
        id: "oceankorpayco",
        title: oceankorpayco_settings.title,
        icons: oceankorpayco_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceankorpayco_Content, null ),
    edit: Object( window.wp.element.createElement )( oceankorpayco_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceankorpayco_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-korpayco-gateway' ),
  /*  supports: {
        features: oceankorpayco_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceankorpayco_Block_Gateway );