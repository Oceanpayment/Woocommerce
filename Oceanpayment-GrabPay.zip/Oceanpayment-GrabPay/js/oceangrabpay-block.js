
const oceangrabpay_settings = window.wc.wcSettings.getSetting( 'oceangrabpay_data', {} );


const oceangrabpay_label = window.wp.htmlEntities.decodeEntities( oceangrabpay_settings.title ) || window.wp.i18n.__( 'Oceanpayment Naverpay Payment Gateway', 'oceanpayment-grabpay-gateway' );




const oceangrabpay_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceangrabpay_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceangrabpay-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceangrabpay_Block_Gateway = {
    name: 'oceangrabpay',

    label: React.createElement(I, {
        id: "oceangrabpay",
        title: oceangrabpay_settings.title,
        icons: oceangrabpay_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceangrabpay_Content, null ),
    edit: Object( window.wp.element.createElement )( oceangrabpay_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceangrabpay_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-grabpay-gateway' ),
  /*  supports: {
        features: oceangrabpay_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceangrabpay_Block_Gateway );