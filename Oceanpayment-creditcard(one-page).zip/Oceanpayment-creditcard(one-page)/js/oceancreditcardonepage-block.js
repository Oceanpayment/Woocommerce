
const oceancreditcardonepage_settings = window.wc.wcSettings.getSetting( 'oceancreditcardonepage_data', {} );


const oceancreditcardonepage_label = window.wp.htmlEntities.decodeEntities( oceancreditcardonepage_settings.title ) || window.wp.i18n.__( 'Oceanpayment CreditCard Onepage Payment Gateway', 'oceanpayment-creditcardonepage-gateway' );




const oceancreditcardonepage_Content = (props ) => {
	var submiturl = '';
	if(oceancreditcardonepage_settings.submiturl != 'https://secure.oceanpayment.com/gateway/direct/pay'){
		submiturl = oceancreditcardonepage_settings.submiturl;
	}
	var configuration = {'showCardName': true};
	const script_html= 'jQuery(function() {\n' +
		'                    //如需修改支付语言，可传入语言代码\n' +
		'  onePageCardData.init(' +
		'        "'+submiturl+'",' +
		'        "'+oceancreditcardonepage_settings.cssurl+'",' +
		'        "'+oceancreditcardonepage_settings.language+'",' +
		'        "'+oceancreditcardonepage_settings.public_key+'",' +
		'        "'+oceancreditcardonepage_settings.SSL+oceancreditcardonepage_settings.HTTP_HOST+'",' +
		'        ' + JSON.stringify(configuration) +
		'  );\n' +
		'                    $("#op-payment-icons img").css("display", "inline-block");\n' +
		'                });\n' +
		'                \n' +
		'jQuery(function($) {\n' +
		'                    var allowNextSubmit = false;\n' +
		'                    var validating = false;\n' +
		'\n' +
		'                    window.oceanpaymentCallBack = function(data) {\n' +
		'                        data = data || {};\n' +
		'                        $("#errorMsg").val(data.errorMsg || "");\n' +
		'                        $("#card_data_info").val(data.card_data || "");\n' +
		'                        if (typeof data.card_name !== "undefined") {\n' +
		'                            $("#card_name_info").val(data.card_name || "");\n' +
		'                        }\n' +
		'                    };\n' +
		'\n' +
		'                    $("#place_order").off("click.oceanpayment").on("click.oceanpayment", function(e) {\n' +
		'                        var cb = document.getElementById(\n' +
		'                            "payment_method_oceancreditcardonepage"\n' +
		'                        );\n' +
		'                  // 不是 Oceanpayment \n' +
		'                        if (!cb || !cb.checked) {\n' +
		'                            return true;\n' +
		'                        }\n' +
		'                        if (allowNextSubmit) {\n' +
		'                            allowNextSubmit = false;\n' +
		'                            validating = false;\n' +
		'                            return true;\n' +
		'                        }\n' +
		'                        if (validating) {\n' +
		'                            e.preventDefault();\n' +
		'                            e.stopImmediatePropagation();\n' +
		'                            return false;\n' +
		'                        }\n' +
		'\n' +
		'                        e.preventDefault();\n' +
		'                        e.stopImmediatePropagation();\n' +
		'                        validating = true;\n' +
		'\n' +
		'                        $("#card_data_info").val("");\n' +
		'                        $("#errorMsg").val("");\n' +
		'                        $("#card_name_info").val("");\n' +
		'\n' +
		'                         // 调用 Oceanpayment SDK \n' +
		'                        try {\n' +
		'                            onePageCardData.OceanpaymentValidateResult();\n' +
		'                        } catch (err) {\n' +
		'                            console.error(\n' +
		'                                "Oceanpayment validation error:",\n' +
		'                                err\n' +
		'                            );\n' +
		'                            validating = false;\n' +
		'                            return false;\n' +
		'                        }\n' +
		'                        // 等待 Oceanpayment callback \n' +
		'                        var timer = setInterval(function() {\n' +
		'                            var errorMsg = $("#errorMsg").val();\n' +
		'                            var cardData = $("#card_data_info").val();\n' +
		'                            var cardName = $("#card_name_info").val();\n' +
		'\n' +
		'                            if (errorMsg !== "") {\n' +
		'                                clearInterval(timer);\n' +
		'                                validating = false;\n' +
		'                                return;\n' +
		'                            }\n' +
		'\n' +
		'                            if ( cardData !== "" && cardName !== "" ) {\n' +
		'                                clearInterval(timer);\n' +
		'                                allowNextSubmit = true;\n' +
		'                                validating = false;\n' +
		'                                $("#place_order").trigger("click");\n' +
		'                                return;\n' +
		'                            }\n' +
		'                        }, 80);\n' +
		'                        setTimeout(function() {\n' +
		'                            clearInterval(timer);\n' +
		'                            if (validating) {\n' +
		'                                validating = false;\n' +
		'                                allowNextSubmit = false;\n' +
		'                            }\n' +
		'                        }, 10000);\n' +
		'                        return false;\n' +
		'                    })\n' +
		'                })';

	var text =  React.createElement("div", {id:'card_data_from'},React.createElement("div", {className:'op-payment-icons',id:'oceanpayment-element'})

	);


	const { eventRegistration, emitResponse } = props;
	const { onPaymentSetup } = eventRegistration;


	window.wp.element.useEffect(() => {
		const div = document.createElement('input');
		div.className='card_data';
		div.id='card_data_info';
		div.type='hidden';
		div.innerHTML = '';
		document.getElementById('card_data_from').appendChild(div);

		const card_name_input = document.createElement('input');
		card_name_input.className='card_name';
		card_name_input.id='card_name_info';
		card_name_input.type='hidden';
		card_name_input.innerHTML = '';
		document.getElementById('card_data_from').appendChild(card_name_input);

		const error_msg_input = document.createElement('input');
		error_msg_input.className='errorMsg';
		error_msg_input.id='errorMsg';
		error_msg_input.type='hidden';
		error_msg_input.innerHTML = '';
		document.getElementById('card_data_from').appendChild(error_msg_input);
		//添加js
		const script = document.createElement('script');
		script.innerHTML = script_html;

		document.getElementById('card_data_from').appendChild(script);
	}, []);

	window.wp.element.useEffect( () => {

		const unsubscribe = onPaymentSetup( async () => {

			const error_msg = $('#errorMsg').val();
			if(error_msg != ''){
				return {
					type: emitResponse.responseTypes.ERROR,
					message: error_msg,
				};
			}
			const myGatewayCardData = $('#card_data_info').val();
			const myGatewayCardName = $('#card_name_info').val();

			const customDataIsValid = !! myGatewayCardData.length;
			if ( customDataIsValid ) {
				return {
					type: emitResponse.responseTypes.SUCCESS,
					meta: {
						paymentMethodData: {
							myGatewayCardData,
							myGatewayCardName,
						},
					},
				};
			}

			return {
				type: emitResponse.responseTypes.ERROR,
				message: 'There was an error',
			};
		} );
		// Unsubscribes when this component is unmounted.
		return () => {
			unsubscribe();
		};
	}, [
		emitResponse.responseTypes.ERROR,
		emitResponse.responseTypes.SUCCESS,
		onPaymentSetup,
	] );
	return text;

};


var I = function(e) {
	var t = e.components,
		n = e.title,
		r = e.icons,
		a = e.id;
	Array.isArray(r) || (r = [r]);
	var o = t.PaymentMethodLabel,
		i = t.PaymentMethodIcons;
	return React.createElement("div", {
		className: "wc-oceancreditcardonepage-blocks-payment-method__label ".concat(a)
	}, React.createElement(o, {
		text: n
	}), React.createElement(i, {
		icons: r
	}))
};


const Oceancreditcardonepage_Block_Gateway = {
	name: 'oceancreditcardonepage',

	label: React.createElement(I, {
		id: "oceancreditcardonepage",
		title: oceancreditcardonepage_settings.title,
		icons: oceancreditcardonepage_settings.icons
	}),

	content: Object( window.wp.element.createElement )( oceancreditcardonepage_Content, null ),
	edit: Object( window.wp.element.createElement )( oceancreditcardonepage_Content, null ),
	canMakePayment: () => true,
	ariaLabel: oceancreditcardonepage_label,

};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceancreditcardonepage_Block_Gateway );
