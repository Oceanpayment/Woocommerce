<?php
/*
	Plugin Name: Oceanpayment  菲律宾网银转账| PHL_Direct_OnlineBank
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment  菲律宾网银转账| PHL_Direct_OnlineBank.
	Version: 1.0
	Author: Oceanpayment
	Requires at least: 1.0
	Tested up to: 1.0
    Text Domain: oceanpayment-phl_direct_onlinebank-gateway
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceanphl_direct_onlinebank', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceanphl_direct_onlinebank_init', 0 );

add_filter('woocommerce_payment_gateways', 'woocommerce_oceanphl_direct_onlinebank_add_gateway' );

/**
 * Initialize the gateway.
 *
 * @since 1.0
 */
function woocommerce_oceanphl_direct_onlinebank_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceanphl_direct_onlinebank.php' ) );


} // End woocommerce_oceanphl_direct_onlinebank_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.0
 */
function woocommerce_oceanphl_direct_onlinebank_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceanphl_direct_onlinebank';
	return $methods;
} // End woocommerce_oceanphl_direct_onlinebank_add_gateway()

/**
 * Custom function to declare compatibility with cart_checkout_blocks feature
 */
function wc_oceanphl_direct_onlinebank_declare_cart_checkout_blocks_compatibility() {
    // Check if the required class exists
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        // Declare compatibility for 'cart_checkout_blocks'
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
}
add_filter('woocommerce_gateway_icon', 'custom_payment_icon_by_phl_direct_onlinebank', 10, 2);
function custom_payment_icon_by_phl_direct_onlinebank($icon,$gateway_id) {
	// 只在结账页面应用
	if (!is_checkout() && !is_wc_endpoint_url('order-pay')) return $icon;

	switch ($gateway_id) {
		case 'oceanphl_direct_onlinebank':
			$src = plugins_url( 'images/op_phl_direct_onlinebank.svg', __FILE__ );
			return "<img src=".$src." style='height:40px;'>";
			break;
	}

	return $icon;
}

// Hook the custom function to the 'before_woocommerce_init' action
add_action('before_woocommerce_init', 'wc_oceanphl_direct_onlinebank_declare_cart_checkout_blocks_compatibility');


add_action( 'woocommerce_blocks_loaded', 'wc_oceanphl_direct_onlinebank_register_order_approval_payment_method_type' );

function wc_oceanphl_direct_onlinebank_register_order_approval_payment_method_type() {

    // Check if the required class exists
    if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
        return;
    }

    // Include the custom Blocks Checkout class
    require_once plugin_dir_path(__FILE__) . 'oceanphl_direct_onlinebank-block.php';
    // Hook the registration function to the 'woocommerce_blocks_payment_method_type_registration' action
    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
            // Register an instance of My_Custom_Gateway_Blocks
            $payment_method_registry->register( new Oceanphl_direct_onlinebank_Gateway_Blocks );
        }
    );
}
