
const oceanphl_direct_onlinebank_settings = window.wc.wcSettings.getSetting( 'oceanphl_direct_onlinebank_data', {} );


const oceanphl_direct_onlinebank_label = window.wp.htmlEntities.decodeEntities( oceanphl_direct_onlinebank_settings.title ) || window.wp.i18n.__( 'Oceanpayment Naverpay Payment Gateway', 'oceanpayment-phl_direct_onlinebank-gateway' );




const oceanphl_direct_onlinebank_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanphl_direct_onlinebank_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanphl_direct_onlinebank-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanphl_direct_onlinebank_Block_Gateway = {
    name: 'oceanphl_direct_onlinebank',

    label: React.createElement(I, {
        id: "oceanphl_direct_onlinebank",
        title: oceanphl_direct_onlinebank_settings.title,
        icons: oceanphl_direct_onlinebank_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanphl_direct_onlinebank_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanphl_direct_onlinebank_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanphl_direct_onlinebank_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-phl_direct_onlinebank-gateway' ),
  /*  supports: {
        features: oceanphl_direct_onlinebank_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanphl_direct_onlinebank_Block_Gateway );