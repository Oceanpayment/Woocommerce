<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanphl_direct_onlinebank_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanphl_direct_onlinebank';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanphl_direct_onlinebank_settings', [] );
        $this->gateway = new WC_Gateway_Oceanphl_direct_onlinebank();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceanphl_direct_onlinebank-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanphl_direct_onlinebank-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {
            wp_set_script_translations( 'oceanphl_direct_onlinebank-blocks-integration');

        }


        return [ 'oceanphl_direct_onlinebank-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'ph-onlinebank_icon',
            'alt' => 'PHL_Direct_OnlineBank',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_phl_direct_onlinebank.svg' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>
