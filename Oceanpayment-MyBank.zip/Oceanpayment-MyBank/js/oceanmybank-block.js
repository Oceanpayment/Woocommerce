
const oceanmybank_settings = window.wc.wcSettings.getSetting( 'oceanmybank_data', {} );


const oceanmybank_label = window.wp.htmlEntities.decodeEntities( oceanmybank_settings.title ) || window.wp.i18n.__( 'Oceanpayment MyBank Payment Gateway', 'oceanpayment-mybank-gateway' );




const oceanmybank_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanmybank_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanmybank-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanmybank_Block_Gateway = {
    name: 'oceanmybank',

    label: React.createElement(I, {
        id: "oceanmybank",
        title: oceanmybank_settings.title,
        icons: oceanmybank_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanmybank_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanmybank_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanmybank_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-mybank-gateway' ),
  /*  supports: {
        features: oceanmybank_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanmybank_Block_Gateway );