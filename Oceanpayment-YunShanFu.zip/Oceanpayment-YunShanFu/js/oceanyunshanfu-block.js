
const oceanyunshanfu_settings = window.wc.wcSettings.getSetting( 'oceanyunshanfu_data', {} );


const oceanyunshanfu_label = window.wp.htmlEntities.decodeEntities( oceanyunshanfu_settings.title ) || window.wp.i18n.__( 'Oceanpayment YunShanFu Payment Gateway', 'oceanpayment-yunshanfu-gateway' );




const oceanyunshanfu_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanyunshanfu_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanyunshanfu-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanyunshanfu_Block_Gateway = {
    name: 'oceanyunshanfu',

    label: React.createElement(I, {
        id: "oceanyunshanfu",
        title: oceanyunshanfu_settings.title,
        icons: oceanyunshanfu_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanyunshanfu_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanyunshanfu_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanyunshanfu_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-yunshanfu-gateway' ),
  /*  supports: {
        features: oceanyunshanfu_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanyunshanfu_Block_Gateway );