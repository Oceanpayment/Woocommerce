<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanyunshanfu_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanyunshanfu';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanyunshanfu_settings', [] );
        $this->gateway = new WC_Gateway_Oceanyunshanfu();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceanyunshanfu-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanyunshanfu-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceanyunshanfu-blocks-integration');
            
        }


        return [ 'oceanyunshanfu-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'yunshanfu_icon',
            'alt' => 'YunShanFu',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_yunshanfu.png' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>