
const oceantruemoney_settings = window.wc.wcSettings.getSetting( 'oceantruemoney_data', {} );


const oceantruemoney_label = window.wp.htmlEntities.decodeEntities( oceantruemoney_settings.title ) || window.wp.i18n.__( 'Oceanpayment Truemoney Payment Gateway', 'oceanpayment-truemoney-gateway' );




const oceantruemoney_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceantruemoney_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceantruemoney-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceantruemoney_Block_Gateway = {
    name: 'oceantruemoney',

    label: React.createElement(I, {
        id: "oceantruemoney",
        title: oceantruemoney_settings.title,
        icons: oceantruemoney_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceantruemoney_Content, null ),
    edit: Object( window.wp.element.createElement )( oceantruemoney_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceantruemoney_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-truemoney-gateway' ),
  /*  supports: {
        features: oceantruemoney_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceantruemoney_Block_Gateway );