<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanoctopus_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanoctopus';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanoctopus_settings', [] );
        $this->gateway = new WC_Gateway_Oceanoctopus();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceanoctopus-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanoctopus-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceanoctopus-blocks-integration');
            
        }


        return [ 'oceanoctopus-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'octopus_icon',
            'alt' => 'Octopus',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_octopus.svg' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>