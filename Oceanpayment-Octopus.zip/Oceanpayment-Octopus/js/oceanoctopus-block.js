
const oceanoctopus_settings = window.wc.wcSettings.getSetting( 'oceanoctopus_data', {} );


const oceanoctopus_label = window.wp.htmlEntities.decodeEntities( oceanoctopus_settings.title ) || window.wp.i18n.__( 'Oceanpayment Octopus Payment Gateway', 'oceanpayment-octopus-gateway' );




const oceanoctopus_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanoctopus_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanoctopus-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanoctopus_Block_Gateway = {
    name: 'oceanoctopus',

    label: React.createElement(I, {
        id: "oceanoctopus",
        title: oceanoctopus_settings.title,
        icons: oceanoctopus_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanoctopus_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanoctopus_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanoctopus_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-octopus-gateway' ),
  /*  supports: {
        features: oceanoctopus_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanoctopus_Block_Gateway );