
const oceanswish_settings = window.wc.wcSettings.getSetting( 'oceanswish_data', {} );


const oceanswish_label = window.wp.htmlEntities.decodeEntities( oceanswish_settings.title ) || window.wp.i18n.__( 'Oceanpayment Swish Payment Gateway', 'oceanpayment-swish-gateway' );




const oceanswish_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanswish_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanswish-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanswish_Block_Gateway = {
    name: 'oceanswish',

    label: React.createElement(I, {
        id: "oceanswish",
        title: oceanswish_settings.title,
        icons: oceanswish_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanswish_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanswish_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanswish_label,
  /*  supports: {
        features: oceanswish_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanswish_Block_Gateway );