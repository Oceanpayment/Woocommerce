
const oceanvnmlpm_settings = window.wc.wcSettings.getSetting( 'oceanvnmlpm_data', {} );


const oceanvnmlpm_label = window.wp.htmlEntities.decodeEntities( oceanvnmlpm_settings.title ) || window.wp.i18n.__( 'Oceanpayment VNM_LPM Payment Gateway', 'oceanpayment-vnmlpm-gateway' );




const oceanvnmlpm_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanvnmlpm_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanvnmlpm-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanvnmlpm_Block_Gateway = {
    name: 'oceanvnmlpm',

    label: React.createElement(I, {
        id: "oceanvnmlpm",
        title: oceanvnmlpm_settings.title,
        icons: oceanvnmlpm_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanvnmlpm_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanvnmlpm_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanvnmlpm_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-vnmlpm-gateway' ),
  /*  supports: {
        features: oceanvnmlpm_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanvnmlpm_Block_Gateway );