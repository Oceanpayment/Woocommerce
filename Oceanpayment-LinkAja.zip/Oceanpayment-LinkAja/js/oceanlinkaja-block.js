
const oceanlinkaja_settings = window.wc.wcSettings.getSetting( 'oceanlinkaja_data', {} );


const oceanlinkaja_label = window.wp.htmlEntities.decodeEntities( oceanlinkaja_settings.title ) || window.wp.i18n.__( 'Oceanpayment LinkAja Payment Gateway', 'oceanpayment-linkaja-gateway' );




const oceanlinkaja_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanlinkaja_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanlinkaja-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanlinkaja_Block_Gateway = {
    name: 'oceanlinkaja',

    label: React.createElement(I, {
        id: "oceanlinkaja",
        title: oceanlinkaja_settings.title,
        icons: oceanlinkaja_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanlinkaja_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanlinkaja_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanlinkaja_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-linkaja-gateway' ),
  /*  supports: {
        features: oceanlinkaja_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanlinkaja_Block_Gateway );