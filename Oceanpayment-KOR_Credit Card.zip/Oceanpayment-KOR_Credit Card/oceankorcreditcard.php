<?php
/*
	Plugin Name: WooCommerce Oceanpayment KOR_Credit Card Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment KOR_Credit Card Gateway.
	Version: 1.2
	Author: Oceanpayment
	Author URI: http://www.oceanpayment.com/
	Requires at least: 1.0
	Tested up to: 1.0
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceankorcreditcard', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceankorcreditcard_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.2
 */
function woocommerce_oceankorcreditcard_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceankorcreditcard.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceankorcreditcard_add_gateway' );

} // End woocommerce_oceankorcreditcard_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.2
 */
function woocommerce_oceankorcreditcard_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceankorcreditcard';
	return $methods;
} // End woocommerce_oceankorcreditcard_add_gateway()

/**
 * Custom function to declare compatibility with cart_checkout_blocks feature
 */
function wc_oceankorcreditcard_declare_cart_checkout_blocks_compatibility() {
    // Check if the required class exists
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        // Declare compatibility for 'cart_checkout_blocks'
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
}
// Hook the custom function to the 'before_woocommerce_init' action
add_action('before_woocommerce_init', 'wc_oceankorcreditcard_declare_cart_checkout_blocks_compatibility');


add_action( 'woocommerce_blocks_loaded', 'wc_oceankorcreditcard_register_order_approval_payment_method_type' );

function wc_oceankorcreditcard_register_order_approval_payment_method_type() {

    // Check if the required class exists
    if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
        return;
    }

    // Include the custom Blocks Checkout class
    require_once plugin_dir_path(__FILE__) . 'oceankorcreditcard-block.php';
    // Hook the registration function to the 'woocommerce_blocks_payment_method_type_registration' action
    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
            // Register an instance of My_Custom_Gateway_Blocks
            $payment_method_registry->register( new Oceankorcreditcard_Gateway_Blocks );
        }
    );
}
