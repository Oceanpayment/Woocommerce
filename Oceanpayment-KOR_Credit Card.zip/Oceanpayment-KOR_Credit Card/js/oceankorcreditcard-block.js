
const oceankorcreditcard_settings = window.wc.wcSettings.getSetting( 'oceankorcreditcard_data', {} );


const oceankorcreditcard_label = window.wp.htmlEntities.decodeEntities( oceankorcreditcard_settings.title ) || window.wp.i18n.__( 'Oceanpayment KOR_Credit_Card Payment Gateway', 'oceanpayment-korcreditcard-gateway' );




const oceankorcreditcard_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceankorcreditcard_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceankorcreditcard-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceankorcreditcard_Block_Gateway = {
    name: 'oceankorcreditcard',

    label: React.createElement(I, {
        id: "oceankorcreditcard",
        title: oceankorcreditcard_settings.title,
        icons: oceankorcreditcard_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceankorcreditcard_Content, null ),
    edit: Object( window.wp.element.createElement )( oceankorcreditcard_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceankorcreditcard_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-korcreditcard-gateway' ),
  /*  supports: {
        features: oceankorcreditcard_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceankorcreditcard_Block_Gateway );