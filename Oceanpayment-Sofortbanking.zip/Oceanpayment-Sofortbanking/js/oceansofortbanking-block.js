
const oceansofortbanking_settings = window.wc.wcSettings.getSetting( 'oceansofortbanking_data', {} );


const oceansofortbanking_label = window.wp.htmlEntities.decodeEntities( oceansofortbanking_settings.title ) || window.wp.i18n.__( 'Oceanpayment Sofortbanking Payment Gateway', 'oceanpayment-sofortbanking-gateway' );




const oceansofortbanking_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceansofortbanking_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceansofortbanking-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceansofortbanking_Block_Gateway = {
    name: 'oceansofortbanking',

    label: React.createElement(I, {
        id: "oceansofortbanking",
        title: oceansofortbanking_settings.title,
        icons: oceansofortbanking_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceansofortbanking_Content, null ),
    edit: Object( window.wp.element.createElement )( oceansofortbanking_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceansofortbanking_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-sofortbanking-gateway' ),
  /*  supports: {
        features: oceansofortbanking_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceansofortbanking_Block_Gateway );