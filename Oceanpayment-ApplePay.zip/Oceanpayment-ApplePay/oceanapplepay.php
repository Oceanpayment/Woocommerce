<?php
/*
	Plugin Name: WooCommerce Oceanpayment ApplePay Gateway
    Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment ApplePay Gateway.
	Version: 6.0
	Author: Oceanpayment
	Requires at least: 4.0
	Tested up to: 6.1
    Text Domain: oceanpayment-applepay-gateway
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceanapplepay', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceanapplepay_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.0
 */
function woocommerce_oceanapplepay_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceanapplepay.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceanapplepay_add_gateway' );

} // End woocommerce_oceanapplepay_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.0
 */
function woocommerce_oceanapplepay_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceanapplepay';
	return $methods;
} // End woocommerce_oceanapplepay_add_gateway()