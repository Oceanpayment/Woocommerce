<?php
/*
	Plugin Name: WooCommerce Oceanpayment BPI Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment BPI Gateway.
	Version: 1.2
	Author: Oceanpayment
	Author URI: http://www.oceanpayment.com/
	Requires at least: 1.0
	Tested up to: 1.0
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceanbpi', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceanbpi_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.2
 */
function woocommerce_oceanbpi_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceanbpi.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceanbpi_add_gateway' );

} // End woocommerce_oceanbpi_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.2
 */
function woocommerce_oceanbpi_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceanbpi';
	return $methods;
} // End woocommerce_oceanbpi_add_gateway()