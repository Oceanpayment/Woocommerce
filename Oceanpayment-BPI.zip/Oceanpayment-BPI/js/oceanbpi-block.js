
const oceanbpi_settings = window.wc.wcSettings.getSetting( 'oceanbpi_data', {} );


const oceanbpi_label = window.wp.htmlEntities.decodeEntities( oceanbpi_settings.title ) || window.wp.i18n.__( 'Oceanpayment BPI Payment Gateway', 'oceanpayment-bpi-gateway' );




const oceanbpi_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanbpi_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanbpi-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanbpi_Block_Gateway = {
    name: 'oceanbpi',

    label: React.createElement(I, {
        id: "oceanbpi",
        title: oceanbpi_settings.title,
        icons: oceanbpi_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanbpi_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanbpi_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanbpi_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-bpi-gateway' ),
  /*  supports: {
        features: oceanbpi_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanbpi_Block_Gateway );