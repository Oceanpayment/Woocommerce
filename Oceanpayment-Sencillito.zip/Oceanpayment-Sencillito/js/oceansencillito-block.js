
const oceansencillito_settings = window.wc.wcSettings.getSetting( 'oceansencillito_data', {} );


const oceansencillito_label = window.wp.htmlEntities.decodeEntities( oceansencillito_settings.title ) || window.wp.i18n.__( 'Oceanpayment Sencillito Payment Gateway', 'oceanpayment-sencillito-gateway' );




const oceansencillito_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceansencillito_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceansencillito-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceansencillito_Block_Gateway = {
    name: 'oceansencillito',

    label: React.createElement(I, {
        id: "oceansencillito",
        title: oceansencillito_settings.title,
        icons: oceansencillito_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceansencillito_Content, null ),
    edit: Object( window.wp.element.createElement )( oceansencillito_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceansencillito_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-sencillito-gateway' ),
  /*  supports: {
        features: oceansencillito_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceansencillito_Block_Gateway );