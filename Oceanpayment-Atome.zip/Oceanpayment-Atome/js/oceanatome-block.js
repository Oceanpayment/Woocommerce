
const oceanatome_settings = window.wc.wcSettings.getSetting( 'oceanatome_data', {} );


const oceanatome_label = window.wp.htmlEntities.decodeEntities( oceanatome_settings.title ) || window.wp.i18n.__( 'Oceanpayment Atome Payment Gateway', 'oceanpayment-atome-gateway' );




const oceanatome_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanatome_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanatome-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanatome_Block_Gateway = {
    name: 'oceanatome',

    label: React.createElement(I, {
        id: "oceanatome",
        title: oceanatome_settings.title,
        icons: oceanatome_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanatome_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanatome_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanatome_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-atome-gateway' ),
  /*  supports: {
        features: oceanatome_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanatome_Block_Gateway );