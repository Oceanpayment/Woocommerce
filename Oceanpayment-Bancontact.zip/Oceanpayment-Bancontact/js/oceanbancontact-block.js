
const oceanbancontact_settings = window.wc.wcSettings.getSetting( 'oceanbancontact_data', {} );


const oceanbancontact_label = window.wp.htmlEntities.decodeEntities( oceanbancontact_settings.title ) || window.wp.i18n.__( 'Oceanpayment Bancontact Payment Gateway', 'oceanpayment-bancontact-gateway' );




const oceanbancontact_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanbancontact_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanbancontact-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanbancontact_Block_Gateway = {
    name: 'oceanbancontact',

    label: React.createElement(I, {
        id: "oceanbancontact",
        title: oceanbancontact_settings.title,
        icons: oceanbancontact_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanbancontact_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanbancontact_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanbancontact_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-bancontact-gateway' ),
  /*  supports: {
        features: oceanbancontact_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanbancontact_Block_Gateway );