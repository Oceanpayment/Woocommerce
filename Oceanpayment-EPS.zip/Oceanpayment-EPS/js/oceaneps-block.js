
const oceaneps_settings = window.wc.wcSettings.getSetting( 'oceaneps_data', {} );


const oceaneps_label = window.wp.htmlEntities.decodeEntities( oceaneps_settings.title ) || window.wp.i18n.__( 'Oceanpayment EPS Payment Gateway', 'oceanpayment-eps-gateway' );




const oceaneps_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceaneps_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceaneps-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceaneps_Block_Gateway = {
    name: 'oceaneps',

    label: React.createElement(I, {
        id: "oceaneps",
        title: oceaneps_settings.title,
        icons: oceaneps_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceaneps_Content, null ),
    edit: Object( window.wp.element.createElement )( oceaneps_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceaneps_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-eps-gateway' ),
    /*  supports: {
          features: oceaneps_settings.supports,
      },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceaneps_Block_Gateway );