
const oceanunionpay_settings = window.wc.wcSettings.getSetting( 'oceanunionpay_data', {} );


const oceanunionpay_label = window.wp.htmlEntities.decodeEntities( oceanunionpay_settings.title ) || window.wp.i18n.__( 'Oceanpayment UnionPay Payment Gateway', 'oceanpayment-unionpay-gateway' );




const oceanunionpay_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanunionpay_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanunionpay-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanunionpay_Block_Gateway = {
    name: 'oceanunionpay',

    label: React.createElement(I, {
        id: "oceanunionpay",
        title: oceanunionpay_settings.title,
        icons: oceanunionpay_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanunionpay_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanunionpay_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanunionpay_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-unionpay-gateway' ),
  /*  supports: {
        features: oceanunionpay_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanunionpay_Block_Gateway );