<?php
/*
	Plugin Name: Oceanpayment THA_Direct_OnlineBank Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: Oceanpayment THA_Direct_OnlineBank Gateway.
	Version: 6.0
	Author: Oceanpayment
	Requires at least: 4.0
	Tested up to: 6.1
    Text Domain: oceanpayment-thadirectob-gateway
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'oceanpayment-thadirectob-gateway', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );


add_filter('woocommerce_payment_gateways', 'woocommerce_oceanthadirectob_add_gateway' );

add_action( 'plugins_loaded', 'woocommerce_oceanthadirectob_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.4
 */
function woocommerce_oceanthadirectob_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceanthadirectob.php' ) );


} // End woocommerce_oceanthadirectob_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.4
 */
function woocommerce_oceanthadirectob_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceanthadirectob';
	return $methods;
} // End woocommerce_oceanthadirectob_add_gateway()

/**
 * Custom function to declare compatibility with cart_checkout_blocks feature
 */
function wc_oceanthadirectob_declare_cart_checkout_blocks_compatibility() {
    // Check if the required class exists
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        // Declare compatibility for 'cart_checkout_blocks'
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
}
// Hook the custom function to the 'before_woocommerce_init' action
add_action('before_woocommerce_init', 'wc_oceanthadirectob_declare_cart_checkout_blocks_compatibility');


add_action( 'woocommerce_blocks_loaded', 'wc_oceanthadirectob_register_order_approval_payment_method_type' );

add_action(
    'woocommerce_blocks_loaded',
    function() {
        woocommerce_register_additional_checkout_field(
            array(
                'id'            => 'namespace/pay_bankcode',
                'label'         => 'pay_bankCode',
                'optionalLabel' => 'pay_bankCode',
                'location'      => 'contact',
                'type'          => 'select',
                'required'      => false,
                'attributes'    => array(),
                'options'       => [
                    [
                        'value' => 'OMISE_SCB',
                        'label' => 'The siam Commercial Bank'
                    ],
                    [
                        'value' => 'OMISE_KTB',
                        'label' => 'Krung Thai Bank'
                    ],
                    [
                        'value' => 'OMISE_BAY',
                        'label' => 'Krungsri Bank'
                    ],
                    [
                        'value' => 'OMISE_BBL',
                        'label' => 'Bangkok Bank'
                    ]
                ]
            )
        );
    }
);

function wc_oceanthadirectob_register_order_approval_payment_method_type() {

    // Check if the required class exists
    if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
        return;
    }

    // Include the custom Blocks Checkout class
    require_once plugin_dir_path(__FILE__) . 'oceanthadirectob-block.php';
    // Hook the registration function to the 'woocommerce_blocks_payment_method_type_registration' action
    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
            // Register an instance of My_Custom_Gateway_Blocks
            $payment_method_registry->register( new Oceanthadirectob_Gateway_Blocks );
        }
    );
}
