<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanthadirectob_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanthadirectob';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanthadirectob_settings', [] );
        $this->gateway = new WC_Gateway_Oceanthadirectob();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceanthadirectob-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanthadirectob-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceanthadirectob-blocks-integration');
            
        }


        return [ 'oceanthadirectob-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'thadirectob_icon',
            'alt' => 'THA_Direct_OnlineBank',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_thadirectob.png' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>