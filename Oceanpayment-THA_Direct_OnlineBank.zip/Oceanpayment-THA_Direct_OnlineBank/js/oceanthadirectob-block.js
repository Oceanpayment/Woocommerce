
const oceanthadirectob_settings = window.wc.wcSettings.getSetting( 'oceanthadirectob_data', {} );


const oceanthadirectob_label = window.wp.htmlEntities.decodeEntities( oceanthadirectob_settings.title ) || window.wp.i18n.__( 'Oceanpayment THA_Direct_OnlineBank Payment Gateway', 'oceanpayment-thadirectob-gateway' );




const oceanthadirectob_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanthadirectob_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanthadirectob-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanthadirectob_Block_Gateway = {
    name: 'oceanthadirectob',

    label: React.createElement(I, {
        id: "oceanthadirectob",
        title: oceanthadirectob_settings.title,
        icons: oceanthadirectob_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanthadirectob_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanthadirectob_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanthadirectob_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-thadirectob-gateway' ),
  /*  supports: {
        features: oceanthadirectob_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanthadirectob_Block_Gateway );