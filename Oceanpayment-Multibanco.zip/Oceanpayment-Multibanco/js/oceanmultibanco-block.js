
const oceanmultibanco_settings = window.wc.wcSettings.getSetting( 'oceanmultibanco_data', {} );


const oceanmultibanco_label = window.wp.htmlEntities.decodeEntities( oceanmultibanco_settings.title ) || window.wp.i18n.__( 'Oceanpayment Multibanco Payment Gateway', 'oceanpayment-multibanco-gateway' );




const oceanmultibanco_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanmultibanco_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanmultibanco-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanmultibanco_Block_Gateway = {
    name: 'oceanmultibanco',

    label: React.createElement(I, {
        id: "oceanmultibanco",
        title: oceanmultibanco_settings.title,
        icons: oceanmultibanco_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanmultibanco_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanmultibanco_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanmultibanco_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-multibanco-gateway' ),
    /*  supports: {
          features: oceanmultibanco_settings.supports,
      },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanmultibanco_Block_Gateway );