
const oceanakulaku_settings = window.wc.wcSettings.getSetting( 'oceanakulaku_data', {} );


const oceanakulaku_label = window.wp.htmlEntities.decodeEntities( oceanakulaku_settings.title ) || window.wp.i18n.__( 'Oceanpayment Akulaku Payment Gateway', 'oceanpayment-akulaku-gateway' );




const oceanakulaku_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanakulaku_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanakulaku-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanakulaku_Block_Gateway = {
    name: 'oceanakulaku',

    label: React.createElement(I, {
        id: "oceanakulaku",
        title: oceanakulaku_settings.title,
        icons: oceanakulaku_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanakulaku_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanakulaku_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanakulaku_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-akulaku-gateway' ),
  /*  supports: {
        features: oceanakulaku_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanakulaku_Block_Gateway );