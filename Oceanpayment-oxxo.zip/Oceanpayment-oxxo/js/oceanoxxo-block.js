
const oceanoxxo_settings = window.wc.wcSettings.getSetting( 'oceanoxxo_data', {} );


const oceanoxxo_label = window.wp.htmlEntities.decodeEntities( oceanoxxo_settings.title ) || window.wp.i18n.__( 'Oceanpayment OXXO Payment Gateway', 'oceanpayment-oxxo-gateway' );




const oceanoxxo_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanoxxo_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanoxxo-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanoxxo_Block_Gateway = {
    name: 'oceanoxxo',

    label: React.createElement(I, {
        id: "oceanoxxo",
        title: oceanoxxo_settings.title,
        icons: oceanoxxo_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanoxxo_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanoxxo_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanoxxo_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-oxxo-gateway' ),
  /*  supports: {
        features: oceanoxxo_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanoxxo_Block_Gateway );