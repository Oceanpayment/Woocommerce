
const oceanpagoefectivo_settings = window.wc.wcSettings.getSetting( 'oceanpagoefectivo_data', {} );


const oceanpagoefectivo_label = window.wp.htmlEntities.decodeEntities( oceanpagoefectivo_settings.title ) || window.wp.i18n.__( 'Oceanpayment Pago_Efectivo Payment Gateway', 'oceanpayment-pagoefectivo-gateway' );




const oceanpagoefectivo_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanpagoefectivo_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanpagoefectivo-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanpagoefectivo_Block_Gateway = {
    name: 'oceanpagoefectivo',

    label: React.createElement(I, {
        id: "oceanpagoefectivo",
        title: oceanpagoefectivo_settings.title,
        icons: oceanpagoefectivo_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanpagoefectivo_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanpagoefectivo_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanpagoefectivo_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-pagoefectivo-gateway' ),
  /*  supports: {
        features: oceanpagoefectivo_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanpagoefectivo_Block_Gateway );