<?php
/*
	Plugin Name: WooCommerce Oceanpayment Pago Efectivo Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment Pago Efectivo Gateway.
	Version: 1.0
	Author: Oceanpayment
	Requires at least: 1.0
	Tested up to: 1.0
    Text Domain: oceanpayment-pagoefectivo-gateway
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceanpagoefectivo', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceanpagoefectivo_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.0
 */
function woocommerce_oceanpagoefectivo_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceanpagoefectivo.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceanpagoefectivo_add_gateway' );

} // End woocommerce_oceanpagoefectivo_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.0
 */
function woocommerce_oceanpagoefectivo_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceanpagoefectivo';
	return $methods;
} // End woocommerce_oceanpagoefectivo_add_gateway()