
const oceanshopeepay_settings = window.wc.wcSettings.getSetting( 'oceanshopeepay_data', {} );


const oceanshopeepay_label = window.wp.htmlEntities.decodeEntities( oceanshopeepay_settings.title ) || window.wp.i18n.__( 'Oceanpayment ShopeePay Payment Gateway', 'oceanpayment-shopeepay-gateway' );




const oceanshopeepay_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanshopeepay_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanshopeepay-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanshopeepay_Block_Gateway = {
    name: 'oceanshopeepay',

    label: React.createElement(I, {
        id: "oceanshopeepay",
        title: oceanshopeepay_settings.title,
        icons: oceanshopeepay_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanshopeepay_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanshopeepay_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanshopeepay_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-shopeepay-gateway' ),
  /*  supports: {
        features: oceanshopeepay_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanshopeepay_Block_Gateway );