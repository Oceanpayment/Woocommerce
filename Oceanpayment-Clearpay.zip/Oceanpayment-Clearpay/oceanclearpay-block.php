<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanclearpay_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanclearpay';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanclearpay_settings', [] );
        $this->gateway = new WC_Gateway_Oceanclearpay();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceanclearpay-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanclearpay-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceanclearpay-blocks-integration');
            
        }


        return [ 'oceanclearpay-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'clearpay_icon',
            'alt' => 'Clearpay',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/clearpay.png' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>