
const oceanduitnow_settings = window.wc.wcSettings.getSetting( 'oceanduitnow_data', {} );


const oceanduitnow_label = window.wp.htmlEntities.decodeEntities( oceanduitnow_settings.title ) || window.wp.i18n.__( 'Oceanpayment DuitNow Payment Gateway', 'oceanpayment-duitnow-gateway' );




const oceanduitnow_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanduitnow_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanduitnow-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanduitnow_Block_Gateway = {
    name: 'oceanduitnow',

    label: React.createElement(I, {
        id: "oceanduitnow",
        title: oceanduitnow_settings.title,
        icons: oceanduitnow_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanduitnow_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanduitnow_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanduitnow_label,
  /*  supports: {
        features: oceanduitnow_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanduitnow_Block_Gateway );