<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanduitnow_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanduitnow';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanduitnow_settings', [] );
        $this->gateway = new WC_Gateway_Oceanduitnow();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceanduitnow-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanduitnow-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceanduitnow-blocks-integration');
            
        }


        return [ 'oceanduitnow-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'duitnow_icon',
            'alt' => 'DuitNow',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_DuitNow.png' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>