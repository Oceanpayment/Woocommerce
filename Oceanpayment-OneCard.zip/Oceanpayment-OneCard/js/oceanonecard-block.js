
const oceanonecard_settings = window.wc.wcSettings.getSetting( 'oceanonecard_data', {} );


const oceanonecard_label = window.wp.htmlEntities.decodeEntities( oceanonecard_settings.title ) || window.wp.i18n.__( 'Oceanpayment OneCard Payment Gateway', 'oceanpayment-onecard-gateway' );




const oceanonecard_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanonecard_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanonecard-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanonecard_Block_Gateway = {
    name: 'oceanonecard',

    label: React.createElement(I, {
        id: "oceanonecard",
        title: oceanonecard_settings.title,
        icons: oceanonecard_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanonecard_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanonecard_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanonecard_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-onecard-gateway' ),
  /*  supports: {
        features: oceanonecard_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanonecard_Block_Gateway );