
const oceantrustly_settings = window.wc.wcSettings.getSetting( 'oceantrustly_data', {} );


const oceantrustly_label = window.wp.htmlEntities.decodeEntities( oceantrustly_settings.title ) || window.wp.i18n.__( 'Oceanpayment Trustly Payment Gateway', 'oceanpayment-trustly-gateway' );




const oceantrustly_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceantrustly_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceantrustly-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceantrustly_Block_Gateway = {
    name: 'oceantrustly',

    label: React.createElement(I, {
        id: "oceantrustly",
        title: oceantrustly_settings.title,
        icons: oceantrustly_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceantrustly_Content, null ),
    edit: Object( window.wp.element.createElement )( oceantrustly_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceantrustly_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-trustly-gateway' ),
  /*  supports: {
        features: oceantrustly_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceantrustly_Block_Gateway );