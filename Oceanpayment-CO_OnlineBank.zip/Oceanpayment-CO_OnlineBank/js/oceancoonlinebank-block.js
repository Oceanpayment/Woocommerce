
const oceancoonlinebank_settings = window.wc.wcSettings.getSetting( 'oceancoonlinebank_data', {} );


const oceancoonlinebank_label = window.wp.htmlEntities.decodeEntities( oceancoonlinebank_settings.title ) || window.wp.i18n.__( 'Oceanpayment CO_OnlineBank Payment Gateway', 'oceanpayment-coonlinebank-gateway' );




const oceancoonlinebank_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceancoonlinebank_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceancoonlinebank-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceancoonlinebank_Block_Gateway = {
    name: 'oceancoonlinebank',

    label: React.createElement(I, {
        id: "oceancoonlinebank",
        title: oceancoonlinebank_settings.title,
        icons: oceancoonlinebank_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceancoonlinebank_Content, null ),
    edit: Object( window.wp.element.createElement )( oceancoonlinebank_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceancoonlinebank_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-coonlinebank-gateway' ),
  /*  supports: {
        features: oceancoonlinebank_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceancoonlinebank_Block_Gateway );