<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceancoonlinebank_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceancoonlinebank';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceancoonlinebank_settings', [] );
        $this->gateway = new WC_Gateway_Oceancoonlinebank();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceancoonlinebank-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceancoonlinebank-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceancoonlinebank-blocks-integration');
            
        }


        return [ 'oceancoonlinebank-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'coonlinebank_icon',
            'alt' => 'CO_OnlineBank',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_CO_OnlineBank.png' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>