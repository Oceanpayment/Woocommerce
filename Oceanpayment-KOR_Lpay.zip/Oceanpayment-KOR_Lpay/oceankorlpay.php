<?php
/*
	Plugin Name: Oceanpayment KOR_Lpay Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment KOR_Lpay Gateway.
	Version: 1.0
	Author: Oceanpayment
	Requires at least: 1.0
	Tested up to: 1.0
    Text Domain: oceanpayment-korlpay-gateway
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceankorlpay', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceankorlpay_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.0
 */
function woocommerce_oceankorlpay_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceankorlpay.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceankorlpay_add_gateway' );

} // End woocommerce_oceankorlpay_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.0
 */
function woocommerce_oceankorlpay_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceankorlpay';
	return $methods;
} // End woocommerce_oceankorlpay_add_gateway()