
const oceankorlpay_settings = window.wc.wcSettings.getSetting( 'oceankorlpay_data', {} );


const oceankorlpay_label = window.wp.htmlEntities.decodeEntities( oceankorlpay_settings.title ) || window.wp.i18n.__( 'Oceanpayment Lpay Payment Gateway', 'oceanpayment-korlpay-gateway' );




const oceankorlpay_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceankorlpay_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceankorlpay-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceankorlpay_Block_Gateway = {
    name: 'oceankorlpay',

    label: React.createElement(I, {
        id: "oceankorlpay",
        title: oceankorlpay_settings.title,
        icons: oceankorlpay_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceankorlpay_Content, null ),
    edit: Object( window.wp.element.createElement )( oceankorlpay_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceankorlpay_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-korlpay-gateway' ),
  /*  supports: {
        features: oceankorlpay_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceankorlpay_Block_Gateway );