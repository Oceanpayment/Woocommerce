<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanrabbitlinepay_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanrabbitlinepay';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanrabbitlinepay_settings', [] );
        $this->gateway = new WC_Gateway_Oceanrabbitlinepay();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceanrabbitlinepay-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanrabbitlinepay-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceanrabbitlinepay-blocks-integration');
            
        }


        return [ 'oceanrabbitlinepay-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'rabbitlinepay_icon',
            'alt' => 'Rabbit-LinePay',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_rabitlinepay.png' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>