
const oceanrabbitlinepay_settings = window.wc.wcSettings.getSetting( 'oceanrabbitlinepay_data', {} );


const oceanrabbitlinepay_label = window.wp.htmlEntities.decodeEntities( oceanrabbitlinepay_settings.title ) || window.wp.i18n.__( 'Oceanpayment Rabbit-LinePay Payment Gateway', 'oceanpayment-rabbitlinepay-gateway' );




const oceanrabbitlinepay_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanrabbitlinepay_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanrabbitlinepay-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanrabbitlinepay_Block_Gateway = {
    name: 'oceanrabbitlinepay',

    label: React.createElement(I, {
        id: "oceanrabbitlinepay",
        title: oceanrabbitlinepay_settings.title,
        icons: oceanrabbitlinepay_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanrabbitlinepay_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanrabbitlinepay_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanrabbitlinepay_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-rabbitlinepay-gateway' ),
  /*  supports: {
        features: oceanrabbitlinepay_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanrabbitlinepay_Block_Gateway );