<?php
/*
	Plugin Name: WooCommerce Oceanpayment GooglePay Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment GooglePay Gateway.
	Version: 6.0
	Author: Oceanpayment
	Requires at least: 4.0
	Tested up to: 6.1
    Text Domain: oceanpayment-googlepay-gateway
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceangooglepay', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceangooglepay_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.0
 */
function woocommerce_oceangooglepay_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceangooglepay.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceangooglepay_add_gateway' );

} // End woocommerce_oceangooglepay_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.0
 */
function woocommerce_oceangooglepay_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceangooglepay';
	return $methods;
} // End woocommerce_oceangooglepay_add_gateway()