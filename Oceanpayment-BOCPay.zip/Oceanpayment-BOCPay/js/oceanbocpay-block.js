
const oceanbocpay_settings = window.wc.wcSettings.getSetting( 'oceanbocpay_data', {} );


const oceanbocpay_label = window.wp.htmlEntities.decodeEntities( oceanbocpay_settings.title ) || window.wp.i18n.__( 'Oceanpayment BOCPay Payment Gateway', 'oceanpayment-bocpay-gateway' );




const oceanbocpay_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanbocpay_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanbocpay-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanbocpay_Block_Gateway = {
    name: 'oceanbocpay',

    label: React.createElement(I, {
        id: "oceanbocpay",
        title: oceanbocpay_settings.title,
        icons: oceanbocpay_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanbocpay_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanbocpay_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanbocpay_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-bocpay-gateway' ),
  /*  supports: {
        features: oceanbocpay_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanbocpay_Block_Gateway );