
const oceandcep_settings = window.wc.wcSettings.getSetting( 'oceandcep_data', {} );


const oceandcep_label = window.wp.htmlEntities.decodeEntities( oceandcep_settings.title ) || window.wp.i18n.__( 'Oceanpayment DCEP Payment Gateway', 'oceanpayment-dcep-gateway' );




const oceandcep_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceandcep_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceandcep-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceandcep_Block_Gateway = {
    name: 'oceandcep',

    label: React.createElement(I, {
        id: "oceandcep",
        title: oceandcep_settings.title,
        icons: oceandcep_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceandcep_Content, null ),
    edit: Object( window.wp.element.createElement )( oceandcep_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceandcep_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-dcep-gateway' ),
  /*  supports: {
        features: oceandcep_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceandcep_Block_Gateway );