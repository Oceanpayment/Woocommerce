<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceandcep_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceandcep';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceandcep_settings', [] );
        $this->gateway = new WC_Gateway_Oceandcep();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceandcep-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceandcep-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceandcep-blocks-integration');
            
        }


        return [ 'oceandcep-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'dcep_icon',
            'alt' => 'DCEP',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_dcep.png' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>