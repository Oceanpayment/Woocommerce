<?php
/*
	Plugin Name: WooCommerce Oceanpayment DCEP Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment DCEP Gateway.
	Version: 6.0
	Author: Oceanpayment
	Requires at least: 4.0
	Tested up to: 6.1
    Text Domain: oceanpayment-dcep-gateway
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceandcep', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceandcep_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.2
 */
function woocommerce_oceandcep_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceandcep.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceandcep_add_gateway' );

} // End woocommerce_oceandcep_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.2
 */
function woocommerce_oceandcep_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceandcep';
	return $methods;
} // End woocommerce_oceandcep_add_gateway()