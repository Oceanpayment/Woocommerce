<?php
/*
	Plugin Name: WooCommerce Oceanpayment brcreditcard Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment brcreditcard Gateway.
	Version: 1.2
	Author: Oceanpayment
	Author URI: http://www.oceanpayment.com/
	Requires at least: 1.0
	Tested up to: 1.0
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceanbrcreditcard', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceanbrcreditcard_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.2
 */
function woocommerce_oceanbrcreditcard_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceanbrcreditcard.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceanbrcreditcard_add_gateway' );

} // End woocommerce_oceanbrcreditcard_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.2
 */
function woocommerce_oceanbrcreditcard_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceanbrcreditcard';
	return $methods;
} // End woocommerce_oceanbrcreditcard_add_gateway()