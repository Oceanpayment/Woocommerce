<?php
/*
	Plugin Name: Oceanpayment  KOR_NAVERPAY Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment  KOR_NAVERPAY Gateway.
	Version: 1.0
	Author: Oceanpayment
	Requires at least: 1.0
	Tested up to: 1.0
    Text Domain: oceanpayment-kornaverpay-gateway
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceankornaverpay', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceankornaverpay_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.0
 */
function woocommerce_oceankornaverpay_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceankornaverpay.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceankornaverpay_add_gateway' );

} // End woocommerce_oceankornaverpay_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.0
 */
function woocommerce_oceankornaverpay_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceankornaverpay';
	return $methods;
} // End woocommerce_oceankornaverpay_add_gateway()