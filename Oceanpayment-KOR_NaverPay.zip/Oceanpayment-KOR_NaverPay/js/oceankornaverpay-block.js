
const oceankornaverpay_settings = window.wc.wcSettings.getSetting( 'oceankornaverpay_data', {} );


const oceankornaverpay_label = window.wp.htmlEntities.decodeEntities( oceankornaverpay_settings.title ) || window.wp.i18n.__( 'Oceanpayment Naverpay Payment Gateway', 'oceanpayment-kornaverpay-gateway' );




const oceankornaverpay_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceankornaverpay_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceankornaverpay-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceankornaverpay_Block_Gateway = {
    name: 'oceankornaverpay',

    label: React.createElement(I, {
        id: "oceankornaverpay",
        title: oceankornaverpay_settings.title,
        icons: oceankornaverpay_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceankornaverpay_Content, null ),
    edit: Object( window.wp.element.createElement )( oceankornaverpay_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceankornaverpay_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-kornaverpay-gateway' ),
  /*  supports: {
        features: oceankornaverpay_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceankornaverpay_Block_Gateway );