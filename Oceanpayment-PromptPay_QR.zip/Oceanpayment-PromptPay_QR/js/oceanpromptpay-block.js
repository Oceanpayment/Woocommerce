
const oceanpromptpay_settings = window.wc.wcSettings.getSetting( 'oceanpromptpay_data', {} );


const oceanpromptpay_label = window.wp.htmlEntities.decodeEntities( oceanpromptpay_settings.title ) || window.wp.i18n.__( 'Oceanpayment PromptPay Payment Gateway', 'oceanpayment-promptpay-gateway' );




const oceanpromptpay_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanpromptpay_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanpromptpay-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanpromptpay_Block_Gateway = {
    name: 'oceanpromptpay',

    label: React.createElement(I, {
        id: "oceanpromptpay",
        title: oceanpromptpay_settings.title,
        icons: oceanpromptpay_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanpromptpay_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanpromptpay_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanpromptpay_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-promptpay-gateway' ),
  /*  supports: {
        features: oceanpromptpay_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanpromptpay_Block_Gateway );