<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanpromptpay_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanpromptpay';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanpromptpay_settings', [] );
        $this->gateway = new WC_Gateway_Oceanpromptpay();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceanpromptpay-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanpromptpay-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceanpromptpay-blocks-integration');
            
        }


        return [ 'oceanpromptpay-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'promptpay_icon',
            'alt' => 'promptpay',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_promptpay.png' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>