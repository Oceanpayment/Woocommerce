
const konbini_settings = window.wc.wcSettings.getSetting( 'konbini_data', {} );


const konbini_label = window.wp.htmlEntities.decodeEntities( konbini_settings.title ) || window.wp.i18n.__( 'Oceanpayment Konbini Payment Gateway', 'oceanpayment-konbini-gateway' );


const konbini_Content = () => {
    return window.wp.htmlEntities.decodeEntities( konbini_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-konbini-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Konbini_Block_Gateway = {
    name: 'konbini',

    label: React.createElement(I, {
        id: "konbini",
        title: konbini_settings.title,
        icons: konbini_settings.icons
    }),

    content: Object( window.wp.element.createElement )( konbini_Content, null ),
    edit: Object( window.wp.element.createElement )( konbini_Content, null ),
    canMakePayment: () => true,
    ariaLabel: konbini_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-konbini-gateway' ),
  /*  supports: {
        features: oceankonbini_settings.supports,
    },*/
};
window.wc.wcBlocksRegistry.registerPaymentMethod( Konbini_Block_Gateway );