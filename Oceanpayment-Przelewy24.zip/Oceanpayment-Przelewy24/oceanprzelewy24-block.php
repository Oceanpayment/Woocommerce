<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanprzelewy24_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanprzelewy24';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanprzelewy24_settings', [] );
        $this->gateway = new WC_Gateway_Oceanprzelewy24();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceanprzelewy24-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanprzelewy24-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceanprzelewy24-blocks-integration');
            
        }


        return [ 'oceanprzelewy24-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'przelewy24_icon',
            'alt' => 'Przelewy24',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_przelewy24.png' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>