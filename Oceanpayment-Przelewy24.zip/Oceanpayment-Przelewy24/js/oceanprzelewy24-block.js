
const oceanprzelewy24_settings = window.wc.wcSettings.getSetting( 'oceanprzelewy24_data', {} );


const oceanprzelewy24_label = window.wp.htmlEntities.decodeEntities( oceanprzelewy24_settings.title ) || window.wp.i18n.__( 'Oceanpayment Przelewy24 Payment Gateway', 'oceanpayment-przelewy24-gateway' );




const oceanprzelewy24_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanprzelewy24_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanprzelewy24-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanprzelewy24_Block_Gateway = {
    name: 'oceanprzelewy24',

    label: React.createElement(I, {
        id: "oceanprzelewy24",
        title: oceanprzelewy24_settings.title,
        icons: oceanprzelewy24_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanprzelewy24_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanprzelewy24_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanprzelewy24_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-przelewy24-gateway' ),
  /*  supports: {
        features: oceanprzelewy24_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanprzelewy24_Block_Gateway );