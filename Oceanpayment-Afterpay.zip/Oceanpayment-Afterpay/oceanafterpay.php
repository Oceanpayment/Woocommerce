<?php
/*
	Plugin Name: WooCommerce Oceanpayment Afterpay Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment Afterpay Gateway.
    Version: 6.0
	Author: Oceanpayment
	Requires at least: 4.0
	Tested up to: 6.1
    Text Domain: oceanpayment-afterpay-gateway
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceanafterpay', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceanafterpay_init', 0 );

/**
 * Initialize the gateway.
 *
 * @since 1.0
 */
function woocommerce_oceanafterpay_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceanafterpay.php' ) );

	add_filter('woocommerce_payment_gateways', 'woocommerce_oceanafterpay_add_gateway' );

} // End woocommerce_oceanafterpay_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.0
 */
function woocommerce_oceanafterpay_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceanafterpay';
	return $methods;
} // End woocommerce_oceanafterpay_add_gateway()