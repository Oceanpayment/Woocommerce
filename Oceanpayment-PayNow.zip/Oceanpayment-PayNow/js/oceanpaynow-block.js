
const oceanpaynow_settings = window.wc.wcSettings.getSetting( 'oceanpaynow_data', {} );


const oceanpaynow_label = window.wp.htmlEntities.decodeEntities( oceanpaynow_settings.title ) || window.wp.i18n.__( 'Oceanpayment Naverpay Payment Gateway', 'oceanpayment-paynow-gateway' );




const oceanpaynow_Content = () => {
    return window.wp.htmlEntities.decodeEntities( oceanpaynow_settings.description || '' );
};


var I = function(e) {
    var t = e.components,
        n = e.title,
        r = e.icons,
        a = e.id;
    Array.isArray(r) || (r = [r]);
    var o = t.PaymentMethodLabel,
        i = t.PaymentMethodIcons;

    const style = {
        'align-items': 'center',
        'display': 'flex',
        'width': '100%'
    };

    return React.createElement("div", {
        className: "wc-oceanpaynow-blocks-payment-method__label ".concat(a),
        style:style
    }, React.createElement(o, {
        text: n
    }), React.createElement(i, {
        icons: r
    }))
};
const Oceanpaynow_Block_Gateway = {
    name: 'oceanpaynow',

    label: React.createElement(I, {
        id: "oceanpaynow",
        title: oceanpaynow_settings.title,
        icons: oceanpaynow_settings.icons
    }),

    content: Object( window.wp.element.createElement )( oceanpaynow_Content, null ),
    edit: Object( window.wp.element.createElement )( oceanpaynow_Content, null ),
    canMakePayment: () => true,
    ariaLabel: oceanpaynow_label,
    // placeOrderButtonLabel: window.wp.i18n.__( 'Proceed to Oceanpayment', 'oceanpayment-paynow-gateway' ),
  /*  supports: {
        features: oceanpaynow_settings.supports,
    },*/
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Oceanpaynow_Block_Gateway );