<?php
/*
	Plugin Name: Oceanpayment  PayNow Gateway
	Plugin URI: http://www.oceanpayment.com/
	Description: WooCommerce Oceanpayment  PAYNOW Gateway.
	Version: 1.0
	Author: Oceanpayment
	Requires at least: 1.0
	Tested up to: 1.0
    Text Domain: oceanpayment-paynow-gateway
*/


/**
 * Plugin updates
 */

load_plugin_textdomain( 'wc_oceanpaynow', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ) );

add_action( 'plugins_loaded', 'woocommerce_oceanpaynow_init', 0 );

add_filter('woocommerce_payment_gateways', 'woocommerce_oceanpaynow_add_gateway' );
/**
 * Initialize the gateway.
 *
 * @since 1.0
 */
function woocommerce_oceanpaynow_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	require_once( plugin_basename( 'class-wc-oceanpaynow.php' ) );


} // End woocommerce_oceanpaynow_init()

/**
 * Add the gateway to WooCommerce
 *
 * @since 1.0
 */
function woocommerce_oceanpaynow_add_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Oceanpaynow';
	return $methods;
} // End woocommerce_oceanpaynow_add_gateway()

/**
 * Custom function to declare compatibility with cart_checkout_blocks feature
 */
function wc_oceanpaynow_declare_cart_checkout_blocks_compatibility() {
    // Check if the required class exists
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        // Declare compatibility for 'cart_checkout_blocks'
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
}
// Hook the custom function to the 'before_woocommerce_init' action
add_action('before_woocommerce_init', 'wc_oceanpaynow_declare_cart_checkout_blocks_compatibility');


add_action( 'woocommerce_blocks_loaded', 'wc_oceanpaynow_register_order_approval_payment_method_type' );

function wc_oceanpaynow_register_order_approval_payment_method_type() {

    // Check if the required class exists
    if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
        return;
    }

    // Include the custom Blocks Checkout class
    require_once plugin_dir_path(__FILE__) . 'oceanpaynow-block.php';
    // Hook the registration function to the 'woocommerce_blocks_payment_method_type_registration' action
    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
            // Register an instance of My_Custom_Gateway_Blocks
            $payment_method_registry->register( new Oceanpaynow_Gateway_Blocks );
        }
    );
}