<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class Oceanpaynow_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'oceanpaynow';
    public function initialize() {
        $this->settings = get_option( 'woocommerce_oceanpaynow_settings', [] );
        $this->gateway = new WC_Gateway_Oceanpaynow();
    }

    public function is_active() {
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {

        wp_register_script(
            'oceanpaynow-blocks-integration',
            plugin_dir_url(__FILE__) . 'js/oceanpaynow-block.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'oceanpaynow-blocks-integration');
            
        }


        return [ 'oceanpaynow-blocks-integration' ];
    }


    public function get_payment_method_data() {
        $icons[] = array(
            'id'  => 'paynow_icon',
            'alt' => 'Naverpay',
            'src' => WC_HTTPS::force_https_url( plugins_url('images/op_paynow.svg' , __FILE__ ) )
        );
        return [
            'title' => $this->gateway->title,
            'description' => $this->gateway->description,
            'icons'=>$icons
        ];
    }

}
?>